package com.ebravium.ecarrot.Adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.ebravium.ecarrot.Common.AppList;
import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.ManageDestinationAppDao;

import java.util.ArrayList;


public class AppListAdapter extends ArrayAdapter<AppList> {
    private final DaoMaster daoMaster;
    private final DaoSession daoSession;
    private final SQLiteDatabase db;
    private final ManageDestinationAppDao desti_dao;
    private ArrayList<AppList> array;

    private final Activity context;

    public AppListAdapter(Activity context, ArrayList<AppList> array) {
        // ArrayAdapter needs : 1) Context 2) TextView Resource Id
        super(context, R.layout.applist, array);
        this.context = context;
        this.array = array;
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(context, "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        desti_dao = daoSession.getManageDestinationAppDao();
    }

    @Override
    public int getCount() {
        return this.array.size();
    }
    static class ViewHolder {
        TextView tvappname;
        ToggleButton tglockunlock;
        TextView textViewid;
        public ImageView imageview;

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos=position;
        final AppList applst = this.array.get(position);

        View rowView = convertView;
        // reusing the listView item
        // this is the first
        if (convertView == null) {
            // new object creation
            LayoutInflater inflater = context.getLayoutInflater();

            rowView = inflater.inflate(R.layout.applist, null);
            ViewHolder viewHolder = new ViewHolder();

            viewHolder.tvappname = (TextView) rowView.findViewById(R.id.tvapplist);
            viewHolder.tglockunlock=(ToggleButton)rowView.findViewById(R.id.tglockunlock);
            viewHolder.imageview =(ImageView)rowView.findViewById(R.id.imageView1);
            rowView.setTag(viewHolder);

        }

        final ViewHolder holder = (ViewHolder) rowView.getTag();

        holder.imageview.setImageDrawable(applst.icon);

        holder.tvappname.setText(applst.getAppname());

        if(applst.getLockunlock().equals("1")){
            holder.tglockunlock.setChecked(true);
        }else{
            holder.tglockunlock.setChecked(false);
        }
        holder.tglockunlock.setOnClickListener(new View.OnClickListener() {

            private ContentResolver cr;

            @Override
            public void onClick(View v) {

                new AlertDialog.Builder(context)
                        .setMessage("Save destination app changes")
                        .setCancelable(false)
                        .setPositiveButton("Confirm", new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int which)
                            {


                                if(holder.tglockunlock.isChecked())
                                {
                                    ////Log.e("Firsttttttt", "app name "+applst.getAppname().toString() +"pack name "+applst.getPkgname().toString()+" id"+applst.getId().toString());
                                    //cc.tglockunlock(applst.getAppname().toString(), applst.getPkgname().toString(),applst.getId().toString(),"checked",stname);
                                    String updateQuery = "update " + ManageDestinationAppDao.TABLENAME
                                            + " set " + ManageDestinationAppDao.Properties.Status.columnName + " = '1'"
                                            + " where " + ManageDestinationAppDao.Properties.ChildId.columnName + " = '"+applst.getId()+"' AND "+
                                            ManageDestinationAppDao.Properties.PackageName.columnName+ " = '"+applst.getPkgname()+"'";
                                    Log.e("Update ",updateQuery);
                                    daoSession.getDatabase().execSQL(updateQuery);
                                    applst.setLockunlock("1");

                                }
                                else
                                {
                                    String updateQuery = "update " + ManageDestinationAppDao.TABLENAME
                                            + " set " + ManageDestinationAppDao.Properties.Status.columnName + " = '2'"
                                            + " where " + ManageDestinationAppDao.Properties.ChildId.columnName + " = '"+applst.getId()+"' AND "+
                                            ManageDestinationAppDao.Properties.PackageName.columnName+ " = '"+applst.getPkgname()+"'";
                                    Log.e("Update ",updateQuery);
                                    daoSession.getDatabase().execSQL(updateQuery);
                                  //  cc.tglockunlock(applst.getAppname().toString(), applst.getPkgname().toString(),applst.getId().toString(),"unchecked",stname);
                                    applst.setLockunlock("2");


                                }
                                array.set(pos, applst);

                            }
                        })

                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int which)
                            {
                                if(holder.tglockunlock.isChecked())
                                {
                                    holder.tglockunlock.setChecked(false);
                                }else{
                                    holder.tglockunlock.setChecked(true);
                                }


                            }
                        }).show();



            }
        });


        // will be added into the ListView
        return rowView;

        // patining
    }
}
