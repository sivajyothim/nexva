package com.ebravium.ecarrot.Adapters;

import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.model.Child_Details;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;


/**
 * Created by osourcepro-laptop on 22/6/16.
 */
public class ChildNameAdapter extends ArrayAdapter<Child_Details> {
    List<Child_Details> arrcd;
    Context con;
    LayoutInflater inflater;
    public ChildNameAdapter(Context context, List<Child_Details> objects) {
        super(context, R.layout.childname_list_item , objects);
        arrcd=objects;
        con= context;
        inflater= LayoutInflater.from(con);
    }

    @Override
    public int getCount() {
        return arrcd.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if(convertView==null){
            convertView=  inflater.inflate(R.layout.childname_list_item,null);
            holder= new ViewHolder();
            holder.ivchild= (ImageView)convertView.findViewById(R.id.ivchild);
            holder.tvchildname=(TextView)convertView.findViewById(R.id.tvchildname);


            convertView.setTag(holder);
        }else{
            holder= (ViewHolder)convertView.getTag();
        }
        Child_Details item= arrcd.get(position);

        holder.tvchildname.setText(item.getChild_name());
               return convertView;
    }
    class ViewHolder{
        ImageView ivchild;
        TextView tvchildname;

    }
}
