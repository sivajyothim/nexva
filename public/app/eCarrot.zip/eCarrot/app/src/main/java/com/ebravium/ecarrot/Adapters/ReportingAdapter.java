package com.ebravium.ecarrot.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.ebravium.ecarrot.Common.DetailReporting;
import com.ebravium.ecarrot.R;

import java.util.ArrayList;

/**
 * Created by osourcepro-laptop on 20/9/16.
 */
public class ReportingAdapter extends ArrayAdapter<DetailReporting> {
    private final Context con;
    private final LayoutInflater inflater;
    private final ArrayList<DetailReporting> arrreport;

    public ReportingAdapter(Context context, ArrayList<DetailReporting> arrreport) {
        super(context, R.layout.reporting_list_layout);
        con =context;
         inflater= LayoutInflater.from(con);
        this.arrreport= arrreport;
    }

    @Override
    public int getCount() {
        return arrreport.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if(convertView==null){
           convertView= inflater.inflate(R.layout.reporting_list_layout,null);
            holder= new ViewHolder();
            holder.tvansexp=(TextView)convertView.findViewById(R.id.tvansexp);
            holder.tvquestion=(TextView)convertView.findViewById(R.id.tvquestion);
            holder.tvanswergiven=(TextView)convertView.findViewById(R.id.tvanswergiven);
            holder.tvtimetaken=(TextView)convertView.findViewById(R.id.tvtimetaken);
            holder.tvcorincor=(TextView)convertView.findViewById(R.id.tvcorincor);
            convertView.setTag(holder);
        }else{
            holder=(ViewHolder)convertView.getTag();
        }
        DetailReporting dpr= arrreport.get(position);
        holder.tvquestion.setText(dpr.getQuestion());
        holder.tvansexp.setText(dpr.getExpectedAnswer());

        holder.tvanswergiven.setText(dpr.getAnswerGiven());
        holder.tvtimetaken.setText(dpr.getTimeTaken());
        holder.tvcorincor.setText(dpr.getStatus());
        return convertView;
    }

    class ViewHolder
    {
        TextView tvquestion, tvanswergiven, tvansexp, tvtimetaken,tvcorincor;
    }
}
