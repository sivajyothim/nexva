package com.ebravium.ecarrot.Adapters;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.model.TimeUsageDetails;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by dhirajghorpade on 14/10/17.
 */

public class UsageDetailReport extends ArrayAdapter<TimeUsageDetails> {
    private final LayoutInflater inflater;
    Context context;
    ArrayList<TimeUsageDetails>arrayList;
    private Drawable icon;

    public UsageDetailReport(Context context, ArrayList<TimeUsageDetails>arrayList) {
        super(context, R.layout.lst_usage_report);
        this.context= context;
        this.arrayList = arrayList;
        inflater= LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        ViewHolder holder;
        if(convertView==null){
            convertView=  inflater.inflate(R.layout.lstdetailusagereport,null);
            holder= new ViewHolder();
            holder.ivappicon= (ImageView)convertView.findViewById(R.id.ivappicon);
            holder.tvappname=(TextView)convertView.findViewById(R.id.tvappname);
            holder.tvtimes=(TextView)convertView.findViewById(R.id.tvtimes);
            holder.tvTotal=(TextView)convertView.findViewById(R.id.tvTotal);

            convertView.setTag(holder);
        }else{
            holder= (ViewHolder)convertView.getTag();
        }
        TimeUsageDetails time = arrayList.get(position);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        String starttime = ""+sdf.format(new Date(Long.parseLong(time.getStartTime())));
        String stoptime = ""+sdf.format(new Date(Long.parseLong(time.getStopTime())));
        holder.tvtimes.setText(starttime);
        holder.tvTotal.setText(stoptime);
        holder.tvappname.setText(time.getAppName());
        try {
            icon = context.getPackageManager().getApplicationIcon(time.getPackageName());
            holder.ivappicon.setImageDrawable(icon);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return convertView;

    }

    @Override
    public int getCount() {
        return arrayList.size();
    }
   public class ViewHolder{
        ImageView ivappicon;
        TextView tvappname;
        TextView tvtimes;
        TextView tvTotal;
    }
}
