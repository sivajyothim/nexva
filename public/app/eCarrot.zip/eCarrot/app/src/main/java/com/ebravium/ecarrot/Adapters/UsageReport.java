package com.ebravium.ecarrot.Adapters;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.model.Usage_detail;


import java.util.List;

import static com.ebravium.ecarrot.Common.CommonFuctions.secondsToHrMinSec;

/**
 * Created by osourcepro-laptop on 22/6/16.
 */
public class UsageReport extends ArrayAdapter<Usage_detail> {
    List<Usage_detail> arrcd;
    Context con;
    LayoutInflater inflater;
    public UsageReport(Context context, List<Usage_detail> objects) {
        super(context, R.layout.lst_usage_report, objects);
        arrcd=objects;
        con= context;
        inflater= LayoutInflater.from(con);
    }

    @Override
    public int getCount() {
        return arrcd.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if(convertView==null){
            convertView=  inflater.inflate(R.layout.lst_usage_report,null);
            holder= new ViewHolder();
            holder.ivappicon= (ImageView)convertView.findViewById(R.id.ivappicon);
            holder.tvappname=(TextView)convertView.findViewById(R.id.tvappname);
            holder.tvtimes=(TextView)convertView.findViewById(R.id.tvtimes);
            holder.tvTotal=(TextView)convertView.findViewById(R.id.tvTotal);

            convertView.setTag(holder);
        }else{
            holder= (ViewHolder)convertView.getTag();
        }
        Usage_detail item= arrcd.get(position);
        int temp= Integer.parseInt(item.getTotalTime());

        Log.e("TimeBank","jhjkhk"+temp);
        holder.tvappname.setText(item.getAppName());
        holder.tvtimes.setText(item.getNoOfTime());
        holder.tvTotal.setText(secondsToHrMinSec(""+temp));
        Drawable icon = null;
        try {
            icon = con.getPackageManager().getApplicationIcon(item.getAppPackageName());
            holder.ivappicon.setImageDrawable(icon);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return convertView;
    }
    class ViewHolder{
        ImageView ivappicon;
        TextView tvappname;
        TextView tvtimes;
        TextView tvTotal;
    }
}
