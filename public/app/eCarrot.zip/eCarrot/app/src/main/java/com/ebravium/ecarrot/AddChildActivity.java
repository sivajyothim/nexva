package com.ebravium.ecarrot;

import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.ebravium.ecarrot.ConnectServer.Fetchdata;
import com.ebravium.ecarrot.ConnectServer.JSONResponse;
import com.ebravium.ecarrot.model.Child_Details;
import com.ebravium.ecarrot.model.Child_DetailsDao;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_TRIBE_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.URL_ADD_CHILD;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.url_student;

public class AddChildActivity extends AppCompatActivity implements JSONResponse {

    private EditText etchildname;


    private Button btaddchild;
    private EditText etage;

    private String name;

    private String age;

    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private Child_DetailsDao child_dao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_child);
        initview();
    }

    public void initview() {
        etchildname = (EditText) findViewById(R.id.etchildname);

        btaddchild = (Button) findViewById(R.id.btaddchild);
        etage = (EditText) findViewById(R.id.etage);

        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        child_dao = daoSession.getChild_DetailsDao();
    }

    public void Add_Child(View v) {
        //Tid=847636637dh3783937&Pid=adafcwe1313133&Account=Maggy@aol.com&Name=Maggy&Password=Hello123&Age=9&Gender=1
        name = etchildname.getText().toString();

        age = etage.getText().toString();


        if (!name.equals("") && !age.equals("")) {
            List child = child_dao.queryBuilder().where(Child_DetailsDao.Properties.Child_name.eq(name)).list();
            if (child.size() == 0) {
                Map<String, String> map = new HashMap<String, String>();
                map.put("sname", name);
                map.put("age", age);
                map.put("adminid", readFromPreference(this, PREF_WEB_ID, "0"));
                Fetchdata ft = new Fetchdata(this, url_student, map);
                ft.getData();
                ft.jsonResponse = AddChildActivity.this;
            } else {
                showToast(this, getString(R.string.child_already_exists));
            }
        } else {
            showToast(this, getString(R.string.edit_complete_form));
        }


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        callNewActivity(AddChildActivity.this, HomeActivity.class);
    }

    @Override
    public void getData(JSONObject response) throws JSONException {
        Log.e("Response", response.toString());
        //{ "Status" : "1" , "Id" : "5769d0f473100362bbcca29f" , "Flag" : "0" , "ChildrenList" : ""}
        etchildname.setText("");
        etage.setText("");

        if (response.getString("error123").equals("1")) {

                Child_Details item = new Child_Details();
                item.setChild_id(response.getString("id"));
                item.setImage_url("");
                item.setChild_name(name);
                item.setAge(age);
                daoSession.insert(item);
           showToast(this,getString(R.string.child_added_success));


        }else {
            showToast(this, getString(R.string.unable_add_child));
        }

    }

}