package com.ebravium.ecarrot;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static com.ebravium.ecarrot.Common.CommonFuctions.callhome;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PASSWORD;
import static com.ebravium.ecarrot.Common.eCarrotConstants.anspass;

/**
 * Created by osourcepro-laptop on 30/7/16.
 */

public class AskPassword extends AppCompatActivity {
    private Button btSubmit;
    private EditText etPass;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_check_pass);
        etPass=(EditText)findViewById(R.id.etPass);
        btSubmit=(Button)findViewById(R.id.btSubmit);
        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etPass.getText().toString().equals(readFromPreference(AskPassword.this,PREF_PASSWORD,"0"))){
                    anspass=true;
                    finish();

                }else {
                    showToast(AskPassword.this,getString(R.string.invalid_password));
                }
            }
        });
    }

    @Override
    protected void onPause() {
        finish();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        callhome(this);
        super.onBackPressed();
    }
}
