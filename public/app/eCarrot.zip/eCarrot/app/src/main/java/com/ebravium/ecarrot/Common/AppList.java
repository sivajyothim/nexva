package com.ebravium.ecarrot.Common;

import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;

public class AppList implements Parcelable{
	String id;
	String appname;
	public Drawable icon;
	public Drawable getIcon() {
		return icon;
	}
	public void setIcon(Drawable icon) {
		this.icon = icon;
	}
	public String getPkgname() {
		return pkgname;
	}
	public void setPkgname(String pkgname) {
		this.pkgname = pkgname;
	}
	String pkgname;
	String lockunlock;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAppname() {
		return appname;
	}
	public void setAppname(String appname) {
		this.appname = appname;
	}
	
	
	public String getLockunlock() {
		return lockunlock;
	}
	public void setLockunlock(String lockunlock) {
		this.lockunlock = lockunlock;
	}
	@Override
	public int describeContents() {
		return 0;
	}
	@Override
	public void writeToParcel(Parcel parcel, int arg1) {
		parcel.writeString(this.id);
		parcel.writeString(this.appname);
		parcel.writeString(this.pkgname);
		parcel.writeString(this.lockunlock);
	    parcel.writeValue(icon);
	}
	public static Creator<AppList> CREATOR = new Creator<AppList>() {

		@Override
		public AppList createFromParcel(Parcel parcel) {
			AppList applst = new AppList();
			applst.id=parcel.readString();
			applst.appname = parcel.readString();	
			applst.pkgname = parcel.readString();	
			applst.lockunlock=parcel.readString();
			applst.icon=parcel.readParcelable(Drawable.class.getClassLoader());
			return null;
		}

		@Override
		public AppList[] newArray(int size) {
			return null;
		}
	
	};
	
}
