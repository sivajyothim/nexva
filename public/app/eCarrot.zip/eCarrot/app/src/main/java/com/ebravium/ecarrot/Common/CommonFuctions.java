package com.ebravium.ecarrot.Common;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.ebravium.ecarrot.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

public class CommonFuctions
{
    private static ProgressDialog pDialog;
    private static Dialog dialog;
    public static final String PREF_FILE_NAME="testpref";
    private static ActivityInfo activity;


    public static void callhome(Context activityCon)
    {
        PackageManager pm=activityCon.getPackageManager();
        Intent intentgethome = new Intent("android.intent.action.MAIN");
        intentgethome.addCategory("android.intent.category.HOME");
        List<ResolveInfo> lst = pm.queryIntentActivities(intentgethome, 0);

		/*The app at 0th location is the launcher app of android so need to guide the user to that*/
        ResolveInfo resolveInfo=lst.get(0);
        Log.d("Test", "New Launcher Found: " + resolveInfo.activityInfo.packageName);
        activity=resolveInfo.activityInfo;

        ComponentName name=new ComponentName(activity.applicationInfo.packageName, activity.name);
        Intent  intent = new Intent();
        intent.setComponent(name);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activityCon.startActivity(intent);
    }

    public static void saveToPreference(Context context, String preferenceName, String preferenceValue)
    {
        SharedPreferences sharedPreferences= context.getSharedPreferences(PREF_FILE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor= sharedPreferences.edit();
        editor.putString(preferenceName, preferenceValue);
        editor.commit();
    }

    public static void callNewActivity(Context con, Class abc) {
        Intent intent = new Intent(con,abc);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        con.startActivity(intent);
    }

    public static void callNewActivity_clear(Context con, Class abc)  {
        Intent intent = new Intent(con,abc);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        con.startActivity(intent);
    }
    public static String readFromPreference(Context context, String preferenceName, String defaultValue)
    {
        SharedPreferences sharedPreferences= context.getSharedPreferences(PREF_FILE_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(preferenceName,defaultValue);
    }

    public static void savePreferences(Context activityCon,String key, boolean value) {
        SharedPreferences sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(activityCon);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }
    public static boolean loadSavedPreferences(Context activityCon,String key) {
        SharedPreferences sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(activityCon);
        boolean value = sharedPreferences.getBoolean(key, false);
        return value;
    }

    public static void showProgressDialog(Context con, String message){
        pDialog = new ProgressDialog(con, R.style.MyAlertDialogStyle);
        pDialog.setMessage(message);
        pDialog.setCancelable(false);
        pDialog.show();
    }

    public static void dismissProgress() {
        if (pDialog != null && pDialog.isShowing()) {
            pDialog.dismiss();
        }
    }

    /* Heshan */
    public static void alertUser(Context context, String message, View.OnClickListener onClickListener) {
        if(!((Activity) context).isFinishing()) {

            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }

            dialog = new Dialog(context);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.usage_instruction);
            dialog.setCancelable(false);
            TextView textView = dialog.findViewById(R.id.tvtext);
            textView.setText(message);
            Button button = dialog.findViewById(R.id.btok);
            button.setOnClickListener(onClickListener);
            dialog.show();
        }
    }

    public static void alertPayment(Context context, String message,
                                    View.OnClickListener onClickListener,
                                    View.OnClickListener cancelListener, String title1, String title2) {
        if(!((Activity) context).isFinishing()) {

            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }

            dialog = new Dialog(context);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.payment_instruction);
            dialog.setCancelable(false);
            TextView textView = dialog.findViewById(R.id.tvtext);
            textView.setText(message);
            Button button = dialog.findViewById(R.id.btok);
            button.setText(title1);
            button.setOnClickListener(onClickListener);
            Button buttCancel = dialog.findViewById(R.id.btcancel);
            buttCancel.setText(title2);
            buttCancel.setOnClickListener(cancelListener);
            dialog.show();
        }
    }

    public static void dismissAlert() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }
    /*--end-*/

    public static String secondsToHrMinSec(String sec) {
        int s=Integer.parseInt(sec);
        String str="00:00:00";
        if(s>0){
            str="";
        }
        if(s<0){
            s=s*-1;
            str="-";
        }

        if(s>0) {
            int hour = s / (60 * 60);
            int min = (s - (hour * 60 * 60)) / 60;
            int se = (s - (hour * 60 * 60) - (min * 60));

            if (hour < 10) {
                str += "0" + hour;
            } else {
                str += hour;
            }
            if (min < 10) {
                str += ":0" + min;
            } else {
                str += ":" + min;
            }
            if (se < 10) {
                str += ":0" + se;
            } else {
                str += ":" + se;
            }
        }
        return str;
    }

    public static void hideProgressDialog() {
        if(pDialog!=null)
            if (pDialog.isShowing())
                pDialog.hide();
    }
    public static void showToast(Context con, String str)
    {
        Toast toast = Toast.makeText(con, str, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }
    private final static Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(

            "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                    + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                    + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                    + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                    + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                    + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$");
    private String admin_id;

    public static boolean checkEmail(String email)
    {
        return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
    }

    public static boolean checkCode(String code) {
        int codeLength = code.length();
        return codeLength > 3;
    }

    public static boolean checkPhone(String code) {
        int codeLength = code.length();
        return codeLength > 10;
    }

    /* Heshan */
    public static long getDifferentBetWeenDays(String startDate) {
        long difference = 0;
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Date date = format.parse(startDate);
            long diff = new Date().getTime() - date.getTime();
            long seconds = diff / 1000;
            long minutes = seconds / 60;
            long hours = minutes / 60;
            difference = hours / 24;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return difference;
    }

    public static boolean isNeedToPay(String dueDate) {
        boolean needToPay = false;
        try {
            if (dueDate.equalsIgnoreCase("0")) {
                needToPay = true;
            } else {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                Date date = format.parse(dueDate);
                long diff = new Date().getTime() - date.getTime();
                if (diff > 0) {
                    needToPay = true;
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return needToPay;
    }
    /*--end--*/
}
