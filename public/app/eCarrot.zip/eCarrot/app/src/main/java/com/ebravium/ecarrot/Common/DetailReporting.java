package com.ebravium.ecarrot.Common;

/**
 * Created by osourcepro-laptop on 20/9/16.
 */
public class DetailReporting {
    String Question;
    String AnswerGiven;

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }

    public String getAnswerGiven() {
        return AnswerGiven;
    }

    public void setAnswerGiven(String answerGiven) {
        AnswerGiven = answerGiven;
    }

    public String getExpectedAnswer() {
        return ExpectedAnswer;
    }

    public void setExpectedAnswer(String expectedAnswer) {
        ExpectedAnswer = expectedAnswer;
    }

    public String getTimeTaken() {
        return TimeTaken;
    }

    public void setTimeTaken(String timeTaken) {
        TimeTaken = timeTaken;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    String ExpectedAnswer;
    String TimeTaken;
            String Status;


}
