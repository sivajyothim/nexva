package com.ebravium.ecarrot.Common;

import com.ebravium.ecarrot.Services.CalUseEarnTime;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.TimeBankDao;

/**
 * Created by osourcepro-laptop on 23/8/16.
 */
public class eCarrotConstants
{
        public static final String Urlsite = "http://ecarrot.it/user/index.php/";
        public static final String url_getuid = Urlsite + "user/login";
        public static final String url_student_details = Urlsite + "user/studentviewdetails";
        public static final String url_student=Urlsite+"user/add_student_new";
        public static final String url_reguid = Urlsite + "user/create_user";
        public static final String url_sendpass1 = Urlsite + "forgotcontroller/checkforgot";
        public static final String url_admin_over = Urlsite + "forgotcontroller/adminover";
        public static final String PREF_LOGIN="preflogin";
    /* Heshan */
    public static final String URL_GET_SMS = "http://api.nexva.com/ecarrot/sms";
    public static final String URL_CREATE_USER = "http://api.nexva.com/ecarrot/create-user";
    public static final String URL_CHECK_VERIFICATION_STATUS = "http://api.nexva.com/ecarrot/get-user-status";
    public static final String URL_CHECK_PAYMENT_STATUS = "http://api.nexva.com/ecarrot/get-payment-status";
    public static final String URL_PAYMENT = "http://api.nexva.com/paypal/send-recurring-payment-request/";
    public static final String CURRENCY_CODE = "USD/";
    public static final String PREF_TOKEN="PREF_TOKEN";
    public static final String PREF_MOBILE="PREF_MOBILE";
    public static final String PREF_SHOW_PAY="PREF_SHOW_PAY";
    public static final String PREF_VERIFIED="PREF_VERIFIED";

    /*--end--*/
        public static final String URL_COMMON="http://52.88.66.66:8080/shabam";
        public static final String URL_LOGIN=URL_COMMON+"/LogIn";
        public static final String URL_SIGNUP=URL_COMMON+"/SignUp";
        public static final String URL_ADD_CHILD=URL_COMMON+"/AddChild";

        public static final String PREF_WEB_ID="webid";
        public static final String PREF_EMAIL_ID="emailid";
        public static final String PREF_PASSWORD="pass";
        public static final String PREF_PARENT_NAME="parentname";
        public static final String PREF_TRIBE_NAME="tribename";
        public static final String PREF_TRIBE_ID="tribeid";
        public static final String  PREF_ECARROT_RUNNING="prefeCarrotRunning";
        public static final String PREF_DEVICE_ADMIN="deviceadmin";
        public static final String PREF_ECARROT_CASHOUT="prefcashout";
        public static final String PREF_2_SEC="pref2sec";
        public static final String PREF_4_SEC="pref4sec";
        public static final String PREF_5_SEC="pref5sec";
        public static final String PREF_PENALTY="prefpen";
        public static final String PREF_LOCK="preflock";
        public static  boolean anspass=false;

        public static  boolean bmanagedestination=false;
        public static boolean usagereporting=false;
                public static final String PREF_CHILD_ID="childid";
        public static final String PREF_CHILD_NAME="childname";
        public static TimeBankDao timeBankDao;
        public static  DaoSession daoSessiontime;
        public static String StudentId;
        public static  boolean startedtimer =false;
        public static boolean RunService;
        public static long earntime;

        public static long startTimeBank=0;
        public static long stopTimeBank=0;
        public static long startcountdown=0;
        public static long stopcountdown=0;
        public static CalUseEarnTime objcaltime= new CalUseEarnTime();
        public static final int arr11[]={0,1,2,3,4,5};
        public static final int arr1[]={0};

        public static final int arr22[]={0,1};
        public static final int arr2[]={4};


        public static final int arr33[]={0,1,2};
        public static final int arr3[]={3};


        public static final int arr44[]={0,1,2,3};
        public static final int arr4[]={2};


        public static final int arr55[]={0,1,2,3,4};
        public static final int arr5[]={1};

        public static final int arr66[]={0,1,2,3,4,5,6,7,8,9};
        public static final int arr6[]={1};

        public static final int arr77[]={0,1,2,3,4,5,6,7,8};
        public static final int arr7[]={2};

        public static final int arr88[]={0,1,2,3,4,5,6,7};
        public static final int arr8[]={3};

        public static final int arr99[]={0,1,2,3,4,5,6};
        public static final int arr9[]={4};

        public static final int arr1010[]={0,1,2,3,4,5};
        public static final int arr10[]={5};

        public static final int arr1111[]={0,1,2,3,4,5};
        public static final int arr111[]={0,1,2,3,4,5};

        public static final int arr1212[]={0,1,2,3,4,5,6,7,8,9,10};
        public static final int arr12[]={0,1,2,3,4,5};

        public static final int arr1313[]={1};
        public static final int arr13[]={1,2,3,4,5,6,7,8,9,10};


        public static final int arr1414[]={2};
        public static final int arr14[]={2,3,4,5,6,7,8,9,10};


        public static final int arr1515[]={3};
        public static final int arr15[]={3,4,5,6,7,8,9,10};


        public static final int arr1616[]={4};
        public static final int arr16[]={4,5,6,7,8,9,10};


        public static final int arr1717[]={5};
        public static final int arr17[]={5,6,7,8,9,10};


        public static final int arr1818[]={0,1,2,3,4,5};
        public static final int arr18[]={0,1,2,3,4,5};

        public static final int arr1919[]={0,1,2,3,4,5,6,7,8,9};
        public static final int arr19[]={0,1,2,3,4,5};

        public static final int arr2020[]={0,1,2,3,4,5,6,7,8,9};
        public static final int arr20[]={0,1,2,3,4,5,6,7,8,9};

        public static final int arr2121[]={10,11,12,13,14,15,16,17,18,19,20};
        public static final int arr21[]={0,1,2,3,4,5,6,7,8,9,10};

        public static final int arr2222[]={0,1};
        public static final int arr222[]={0,1,2,3,4,5,6};



        public static final int arr2323[]={0,1};
        public static final int arr23[]={7,8,9,10,11,12};


        public static final int arr2424[]={0,1};
        public static final int arr24[]={0,1,2,3,4,5,6,7,8,9,10,11,12};


        public static final int arr2525[]={2,3,4,5};
        public static final int arr25[]={0,1,2,3,4,5,6};


        public static final int arr2626[]={2,3,4,5};
        public static final int arr26[]={7,8,9,10,11,12};


        public static final int arr2727[]={2,3,4,5};
        public static final int arr27[]={0,1,2,3,4,5,6,7,8,9,10,11,12};

                public static final int arr2828[]={6,7,8};
        public static final int arr28[]={0,1,2,3,4,5,6};


        public static final int arr2929[]={6,7,8};
        public static final int arr29[]={7,8,9,10,11,12};


        public static final int arr3030[]={6,7,8};
        public static final int arr30[]={0,1,2,3,4,5,6,7,8,9,10,11,12};

        public static final int arr3131[]={9,10,11,12};
        public static final int arr31[]={0,1,2,3,4,5,6};

        public static final int arr3232[]={9,10,11,12};
        public static final int arr32[]={7,8,9,10,11,12};

        public static final int arr3333[]={9,10,11,12};
        public static final int arr333[]={0,1,2,3,4,5,6,7,8,9,10,11,12};

        public static final int arr3434[]={0,1,2,3,4,5,6,7,8,9,10,11,12};
        public static final int arr34[]={0,1,2,3,4,5,6};

        public static final int arrlockaddfirst[]={0,1,2,3,4,5,6,7,8,9,10};
        public static final int arrlockaddsecond[]={0,1,2,3,4,5,6,7,8,9,10};

        public static final int arrlocksubfirst[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
        public static final int arrlocksubsecond[]={0,1,2,3,4,5,6,7,8,9,10};

        public static final int arrlockmulfirst[]={0,1,2,3,4,5,6,7,8,9,10,11,12};
        public static final int arrlockmulsecond[]={0,1,2,3,4,5,6,7,8,9,10,11,12};


}
