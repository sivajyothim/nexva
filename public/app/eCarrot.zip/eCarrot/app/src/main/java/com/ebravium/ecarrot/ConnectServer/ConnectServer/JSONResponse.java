package com.ebravium.ecarrot.ConnectServer.ConnectServer;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by osourcepro-laptop on 24/5/16.
 */
public interface JSONResponse
{

        public void getData(JSONObject response) throws JSONException;


}

