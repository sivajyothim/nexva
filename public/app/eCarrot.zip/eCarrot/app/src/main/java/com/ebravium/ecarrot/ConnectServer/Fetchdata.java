package com.ebravium.ecarrot.ConnectServer;

import android.app.Activity;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.ebravium.ecarrot.Common.CommonFuctions;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;

public class Fetchdata {

    Activity con;
    Map<String,String> para;
    public JSONResponse jsonResponse;
    String URL;

    public Fetchdata(Activity con,String Url, Map<String,String> params) {
        this.con=con;
        para=params;
        URL=Url;
        Log.e("url",""+Url);
    }

    public void getData() {
        try {
            RequestQueue requestQueue = Volley.newRequestQueue(con);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            CommonFuctions.hideProgressDialog();
                            Log.e("Response",""+response);
                            try {
                                JSONObject obj= new JSONObject(response);
                                obj.put("error123","1");
                                jsonResponse.getData(obj);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        //    hideProgressDialog();
                        }
                    },

                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            CommonFuctions.hideProgressDialog();
                            //showToast(con,"Unable to connect");
                            JSONObject 	jObj = null;
                            try {
                                jObj = new JSONObject("{\"error123\":2}");
                                jsonResponse.getData(jObj);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }) {

                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams()

                {
                    Map<String, String> params = new HashMap<String, String>();

                    for(Map.Entry<String,String> entry : para.entrySet())
                    {
                            params.put(entry.getKey(),entry.getValue());
                    }
Log.e("Params",""+params);
                    return params;

                }

            };


            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    500000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            requestQueue.add(stringRequest);


        } catch (Exception ex) {


        }
    }

}
