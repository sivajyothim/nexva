package com.ebravium.ecarrot.ConnectServer;

import org.json.JSONException;
import org.json.JSONObject;

public interface JSONResponse {
    public void getData(JSONObject response) throws JSONException;
}

