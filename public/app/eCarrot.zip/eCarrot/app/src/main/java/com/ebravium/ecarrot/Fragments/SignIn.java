package com.ebravium.ecarrot.Fragments;

import android.app.Dialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.ebravium.ecarrot.ConnectServer.Fetchdata;
import com.ebravium.ecarrot.ConnectServer.JSONResponse;
import com.ebravium.ecarrot.HomeActivity;
import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.SplashScreen;
import com.ebravium.ecarrot.model.Child_Details;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.Parent_Login;

import org.json.JSONArray;
import com.ebravium.ecarrot.Common.CommonFuctions;
import com.ebravium.ecarrot.ConnectServer.Fetchdata;
import com.ebravium.ecarrot.ConnectServer.JSONResponse;
import com.ebravium.ecarrot.HomeActivity;
import com.ebravium.ecarrot.PaymentActivity;
import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.Services.CheckUninstall;
import com.ebravium.ecarrot.SplashScreen;
import com.ebravium.ecarrot.VerificationActivity;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.Parent_Login;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.checkEmail;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_EMAIL_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PARENT_NAME;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PASSWORD;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_TRIBE_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_TRIBE_NAME;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.URL_LOGIN;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.savePreferences;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_RUNNING;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PASSWORD;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_SHOW_PAY;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_VERIFIED;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.RunService;
import static com.ebravium.ecarrot.Common.eCarrotConstants.URL_CHECK_PAYMENT_STATUS;
import static com.ebravium.ecarrot.Common.eCarrotConstants.URL_CHECK_VERIFICATION_STATUS;
import static com.ebravium.ecarrot.Common.eCarrotConstants.url_getuid;
import static com.ebravium.ecarrot.Common.eCarrotConstants.url_sendpass1;

public class SignIn extends Fragment implements JSONResponse, View.OnClickListener {


    /* Heshan */
    private static final int STATE_LOGIN = 0;
    private static final int STATE_FORGET = 1;
    private static final int STATE_VERIFI = 2;
    private static final int STATE_PAYMENT = 3;
    private static int state = 0;
    /*--end--*/
    private EditText etEmail;
    private EditText etPass;
    private Button btSignin;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private String Password;
    private String email;
    private TextView tvfpass;
    boolean loginapi=false;
    private Dialog dialogfpass;
    private EditText etdgemail;
    private Button btsend;
    private String userId = "";
    public SignIn() {
        // Required empty public constructor
    }


    public static SignIn newInstance(String param1, String param2) {
        SignIn fragment = new SignIn();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /* Heshan */
    View.OnClickListener dismissListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            callNewActivity_clear(getActivity(), SplashScreen.class);
        }
    };

    View.OnClickListener verifyListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            callNewActivity_clear(getActivity(), VerificationActivity.class);
        }
    };

    View.OnClickListener paymentListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            callNewActivity_clear(getActivity(), PaymentActivity.class);
        }
    };

    View.OnClickListener paymentCancelListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            RunService = false;
            savePreferences(getActivity(),PREF_ECARROT_RUNNING,false);

            Intent intent = new Intent(getActivity(), CheckUninstall.class);
            getActivity().stopService(intent);
        }
    };

    View.OnClickListener remindListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            callNewActivity_clear(getActivity(), PaymentActivity.class);
        }
    };
    /*--end--*/

    void createfpass()
    {
        dialogfpass = new Dialog(getActivity());
        dialogfpass.setTitle(getString(R.string.forgot_password));
        dialogfpass.setContentView(R.layout.fpass);
        etdgemail = (EditText) dialogfpass.findViewById(R.id.etdgemail);
        btsend = (Button) dialogfpass.findViewById(R.id.btsend);

        btsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = etdgemail.getText().toString();
                //check if email address is correct format
                if (checkEmail(email)) {
                    //send this information in the form of key and value format since we are using voley we use Map
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("usr", email);
                    //   Fetchdata is the class under ConnectServer folder which is used to send data to the server.

                    CommonFuctions.showProgressDialog(getActivity(), "Login...");
                    Fetchdata ft = new Fetchdata(getActivity(), url_sendpass1, map);
                    ft.getData();
                    //interface object is set for this fragment class so that once the data is received we get in below mentioned
                    // getdata method which is overrrinden from implemented class JSONResponse
                    ft.jsonResponse = SignIn.this;
                    dialogfpass.cancel();
                    showToast(getActivity(), getString(R.string.email_has_been_sent));
                } else {
                    showToast(getActivity(), getString(R.string.invalid_email_format));
                }
            }
        });

    }
    public void InitView(View v)
    {
        etEmail = (EditText)v.findViewById(R.id.etEmail);
        etPass = (EditText)v.findViewById(R.id.etPass);
        btSignin = (Button) v.findViewById(R.id.btSignin);
        tvfpass =(TextView)v.findViewById(R.id.tvfpass);
        tvfpass.setOnClickListener(this);
        btSignin.setOnClickListener(this);

        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(
                getActivity().getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        createfpass();
    }

    /* Heshan */
    //check verification status
    private void checkUserVerificationStatus(String userId) {
        Map<String, String> map = new HashMap<>();
        map.put("user_id", userId);
        CommonFuctions.showProgressDialog(getActivity(), "Checking user details...");
        Fetchdata ft = new Fetchdata(getActivity(), URL_CHECK_VERIFICATION_STATUS, map);
        ft.getData();
        ft.jsonResponse = this;
    }

    //check payment status
    private void checkUserPaymentStatus(String userId) {
        Map<String, String> map = new HashMap<>();
        map.put("userId", userId);
        CommonFuctions.showProgressDialog(getActivity(), "Checking payment details...");
        Fetchdata ft = new Fetchdata(getActivity(), URL_CHECK_PAYMENT_STATUS, map);
        ft.getData();
        ft.jsonResponse = this;
    }

    private void saveUserDetails() {
        saveToPreference(getActivity(), PREF_PASSWORD, Password);
        Parent_Login pl = new Parent_Login();
        pl.setPass(Password);
        pl.setEmail(email);
        pl.setWeb_id(userId);
        daoSession.insert(pl);
        saveToPreference(getActivity(), PREF_WEB_ID, userId);
    }

    /*--end--*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_sign_in, container, false);
        InitView(v);
        return v;
    }

    @Override
    public void getData(JSONObject response) throws JSONException {
        //Data is received in this method and we save it in the local database and the shared
        // preference.
        /* Heshan*/
        try {
            Log.e("REsponse",response.toString());
            switch (SignIn.state) {
                case SignIn.STATE_LOGIN:
                    if (response.getString("error123").equals("1")) {
                        if (response.has("adminid")) {
                            userId = response.getString("adminid");
                            saveToPreference(getActivity(), PREF_WEB_ID, userId);
                            saveUserDetails();
                            //check user verification status
                            SignIn.state = SignIn.STATE_VERIFI;
                            checkUserVerificationStatus(response.getString("adminid"));
                        } else {
                            CommonFuctions.alertUser(getActivity(),
                                    getResources().getString(R.string.alert_login_failed),
                                    dismissListener);
                        }
                    } else {
                        CommonFuctions.alertUser(getActivity(),
                                getResources().getString(R.string.alert_login_failed),
                                dismissListener);
                    }
                    break;

                case SignIn.STATE_FORGET:
                    break;

                case SignIn.STATE_VERIFI:
                    if (response.getString("error123").equals("1")) {
                        if (response.has("verification_status")) {
                            String status = response.getString("verification_status");
                            String verifiedDate = response.getString("varification_date");

                            if (status.equalsIgnoreCase("1")) {
                                //verified
                                saveToPreference(getActivity(), PREF_VERIFIED, "1");
                                long difference = CommonFuctions.getDifferentBetWeenDays(verifiedDate);
                                if (difference < 11) {

                                    saveToPreference(getActivity(), PREF_SHOW_PAY,"1");
                                    callNewActivity_clear(getActivity(), SplashScreen.class);
                                } else if (difference >= 11 && difference <= 14) {

                                    saveToPreference(getActivity(), PREF_SHOW_PAY,"1");
                                    if (difference == 11) {
                                        CommonFuctions.alertPayment(getActivity(),
                                                getResources().getString(R.string.alert_remind_11),
                                                remindListener, dismissListener, "Ok", "Later");
                                    } else if (difference == 14){
                                        CommonFuctions.alertPayment(getActivity(),
                                                getResources().getString(R.string.alert_remind_14),
                                                remindListener, dismissListener, "Ok", "Later");
                                    } else {
                                        callNewActivity_clear(getActivity(), SplashScreen.class);
                                    }
                                } else {
                                    //check payment status
                                    checkUserPaymentStatus(readFromPreference(getActivity(),
                                            PREF_WEB_ID,""));
                                }
                            } else {
                                CommonFuctions.alertUser(getActivity(),
                                        getResources().getString(R.string.alert_verify_failed),
                                        verifyListener);
                            }
                        } else {
                            CommonFuctions.alertUser(getActivity(),
                                    getResources().getString(R.string.alert_common_failed),
                                    dismissListener);
                        }
                    } else {
                        CommonFuctions.alertUser(getActivity(),
                                getResources().getString(R.string.alert_common_failed),
                                dismissListener);
                    }
                    break;

                case SignIn.STATE_PAYMENT:
                    if (response.getString("error123").equals("1")) {
                        if (response.has("status")) {
                            String status = response.getString("status");
                            String paymentDate = response.getString("paymentDate");

                            if (status.equalsIgnoreCase("1")) {
                                saveUserDetails();
                                long difference = CommonFuctions.getDifferentBetWeenDays(paymentDate);

                                if (difference > 0) {
                                    saveToPreference(getActivity(),PREF_SHOW_PAY,"1");
                                    CommonFuctions.alertPayment(getActivity(),
                                            getResources().getString(R.string.alert_subscription),
                                            paymentListener, paymentCancelListener, "Ok", "Later");
                                } else {

                                    saveToPreference(getActivity(),PREF_SHOW_PAY,"0");
                                    callNewActivity_clear(getActivity(), SplashScreen.class);
                                }
                            } else {
                                CommonFuctions.alertUser(getActivity(),
                                        getResources().getString(R.string.alert_subscription),
                                        paymentListener);
//                                CommonFuctions.alertUser(getActivity(),
//                                        getResources().getString(R.string.alert_trial_expired),
//                                        paymentListener);
                            }
                        } else {
                            CommonFuctions.alertUser(getActivity(),
                                    getResources().getString(R.string.alert_common_failed),
                                    dismissListener);
                        }
                    } else {
                        CommonFuctions.alertUser(getActivity(),
                                getResources().getString(R.string.alert_common_failed),
                                dismissListener);
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
         /*--end--*/
    }

    @Override
    public void onClick(View v)
    {
        if(v.getId()==R.id.btSignin) {
            loginapi=true;
            SignIn.state = SignIn.STATE_LOGIN;
            Password = etPass.getText().toString();
            email = etEmail.getText().toString();
            //check if email address is correct format
            if (checkEmail(email)) {
                //send this information in the form of key and value format since we are using voley we use Map
                Map<String, String> map = new HashMap<String, String>();
                map.put("email", email);
                map.put("password", Password);
                //   Fetchdata is the class under ConnectServer folder which is used to send data to the server.

                Fetchdata ft = new Fetchdata(getActivity(), url_getuid, map);
                ft.getData();
                //interface object is set for this fragment class so that once the data is received we get in below mentioned
                // getdata method which is overrrinden from implemented class JSONResponse
                ft.jsonResponse = SignIn.this;
            }
        }
        if(v.getId()==R.id.tvfpass)
        {
            loginapi=false;
            SignIn.state = SignIn.STATE_FORGET;
            dialogfpass.show();
        }
    }
}
