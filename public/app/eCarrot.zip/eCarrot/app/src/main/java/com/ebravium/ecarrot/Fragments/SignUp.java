package com.ebravium.ecarrot.Fragments;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.ebravium.ecarrot.Common.CommonFuctions;
import com.ebravium.ecarrot.ConnectServer.Fetchdata;
import com.ebravium.ecarrot.ConnectServer.JSONResponse;
import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.VerificationActivity;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.Parent_Login;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.checkEmail;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PASSWORD;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.url_reguid;

public class SignUp extends Fragment implements View.OnClickListener,JSONResponse{
    private EditText etEmail;
    private EditText etPass;

    private EditText etConfPass;
    private Button btSignup;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private String Account;

    private String Password;
    private EditText etchildname;
    private EditText etage;
    private String chdname;
    private String age;
boolean signup = true;

    public SignUp() {
        // Required empty public constructor
    }

    public static SignUp newInstance(String param1, String param2) {
        SignUp fragment = new SignUp();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_sign_up, container, false);
        InitView(v);
        return v;
    }

    public void InitView(View v) {
        etEmail = (EditText) v.findViewById(R.id.etEmail);
        etPass = (EditText) v.findViewById(R.id.etPass);

        etConfPass = (EditText) v.findViewById(R.id.etConfPass);
        btSignup = (Button) v.findViewById(R.id.btSignup);
        etchildname= (EditText)v.findViewById(R.id.etchildname);
        etage = (EditText)v.findViewById(R.id.etage);
        btSignup.setOnClickListener(this);

        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getActivity().getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
    }

    @Override
    public void onClick(View v) {

        if(!etEmail.getText().toString().equals("") &&  !etConfPass.getText().equals("")) {
            if (checkEmail(etEmail.getText().toString())) {
                if(etConfPass.getText().toString().equals(etPass.getText().toString())) {
                    Account=etEmail.getText().toString();
                    Password= etPass.getText().toString();
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("email", ""+Account);
                    map.put("password", ""+Password);
                    CommonFuctions.showProgressDialog(getActivity(), "Signing Up...");
                    Fetchdata ft = new Fetchdata(getActivity(), url_reguid, map);
                    ft.getData();
                    ft.jsonResponse = SignUp.this;
                } else {
                    showToast(getActivity(),getString(R.string.pass_mismatch));
                }
            } else{
                showToast(getActivity(),getString(R.string.invalid_email_address));
           }
        } else {
            showToast(getActivity(),getString(R.string.complete_the_form));
        }
    }

    @Override
    public void getData(JSONObject response) throws JSONException {

        Log.d("SignUp", response.toString());
        //Data is received in this method and we save it in the local database and the shared preference.
        try {
            if(response.getString("error123").equals("1")) {
                if (response.getString("response").equals("1")) {
                    Parent_Login pl = new Parent_Login();
                    pl.setEmail(Account);
                    pl.setWeb_id(response.getString("adminid"));
                    pl.setPass(Password);
                    pl.setVerified(false);
                    daoSession.insert(pl);

                    saveToPreference(getActivity(), PREF_WEB_ID, response.getString("adminid"));
                    saveToPreference(getActivity(), PREF_PASSWORD, Password);

                    /* Heshan */
                    //callNewActivity_clear(getActivity(), SplashScreen.class);
                    callNewActivity_clear(getActivity(), VerificationActivity.class);
                    /*--end--*/
                } else {
                    showToast(getActivity(), getString(R.string.already_exists));
                }
            }
        } catch (JSONException e){
            e.printStackTrace();
        }
    }
}
