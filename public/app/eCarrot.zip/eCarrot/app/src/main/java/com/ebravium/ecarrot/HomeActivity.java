package com.ebravium.ecarrot;

import android.app.AppOpsManager;
import android.app.Dialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.ebravium.ecarrot.ConnectServer.Fetchdata;
import com.ebravium.ecarrot.ConnectServer.JSONResponse;
import com.ebravium.ecarrot.Fragments.SignIn;
import com.ebravium.ecarrot.Reporting.SelectStudentForReporting;
import com.ebravium.ecarrot.Services.CheckUninstall;
import com.ebravium.ecarrot.broadcastreceiver.DeviceAdmin;
import com.ebravium.ecarrot.model.Child_Details;
import com.ebravium.ecarrot.model.Child_DetailsDao;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.TimeBank;
import com.ebravium.ecarrot.model.TimeBankDao;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity;
import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.callhome;
import static com.ebravium.ecarrot.Common.CommonFuctions.checkEmail;
import static com.ebravium.ecarrot.Common.CommonFuctions.loadSavedPreferences;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.savePreferences;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.secondsToHrMinSec;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_CHILD_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_CHILD_NAME;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_DEVICE_ADMIN;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_RUNNING;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_EMAIL_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PASSWORD;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.RunService;
import static com.ebravium.ecarrot.Common.eCarrotConstants.bmanagedestination;
import static com.ebravium.ecarrot.Common.eCarrotConstants.url_admin_over;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_MOBILE;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PASSWORD;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_SHOW_PAY;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.RunService;
import static com.ebravium.ecarrot.Common.eCarrotConstants.bmanagedestination;
import static com.ebravium.ecarrot.Common.eCarrotConstants.url_sendpass1;
import static com.ebravium.ecarrot.Common.eCarrotConstants.url_student_details;
import static com.ebravium.ecarrot.Common.eCarrotConstants.usagereporting;

public class HomeActivity extends AppCompatActivity implements JSONResponse{
    private Button btlogout,btnPay;
    private TextView tvtime;
    private long currenttimebank;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private TimeBankDao timeBankDao;
    private String StudentId;
    private Button btCashout;
    private Dialog dgadminmenu;
    private TextView tvoveride;
    private TextView tvcancel;
    private TextView tvuninstall;
    private TextView tvusageReport;
    private Dialog dgaskpass;
    private EditText etPass;
    private Button btSubmit;
    private TextView tvAddChild;
    private TextView tvReporting;
    private TextView tvmanagedestination;
    private Child_DetailsDao child_dao;
    private TextView tvreward;
    private Dialog dgusage;
    private Button btok;
    private Button btsend;
    private EditText etdgemail;
    private Dialog dialogfpass;
    private TextView tvfpass;
    private TextView tvUserAnalytics;
    private TextView tvlocklvl;
boolean open_Admin=false;

public void Curated_App_Click(View v)
{

    open_Admin=false;
    dgaskpass.show();
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
       Log.e("Home","Home");
if(!loadSavedPreferences(this,PREF_ECARROT_RUNNING))
{
    callhome(this);
    finish();


}else {
    initview();
}
    }
    public void Cashout_Click(View v){
        selectTimebank();
        if(currenttimebank>0)
        {
            callNewActivity_clear(this,Yes_No_Activity.class);
            finish();
        }
    }
    public void Admin_Menu_Click(View v)
    {
        open_Admin=true;
        dgaskpass.show();
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.e("Home","Home");
        if (!loadSavedPreferences(this, PREF_ECARROT_RUNNING)) {
            if(readFromPreference(HomeActivity.this,PREF_WEB_ID,"0").equals("0"))
            {
                callNewActivity_clear(HomeActivity.this,LoginSignupActivity.class);
                finish();
            }else {
                callhome(this);
            }
        }else {
            if (!readFromPreference(this, PREF_CHILD_ID, "0").equals("0")) {
                btlogout.setVisibility(View.VISIBLE);
                tvtime.setVisibility(View.VISIBLE);
                btCashout.setVisibility(View.VISIBLE);
                btlogout.setText("Logout " + readFromPreference(this, PREF_CHILD_NAME, "0"));
                StudentId = readFromPreference(this, PREF_CHILD_ID, "0");
                selectTimebank();
                tvtime.setText(secondsToHrMinSec("" + currenttimebank));
            } else {
                btlogout.setVisibility(View.GONE);
                tvtime.setVisibility(View.GONE);
                btCashout.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onBackPressed() {


    }
    public boolean checkusageStatusEnabled()
    {
        try {
            PackageManager packageManager = getPackageManager();
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(getPackageName(), 0);
            AppOpsManager appOpsManager = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, applicationInfo.uid, applicationInfo.packageName);
            return (mode == AppOpsManager.MODE_ALLOWED);

        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
    public void initDialogs()
    {

        dgusage= new Dialog(this);
        dgusage.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dgusage.setContentView(R.layout.usage_instruction);
        dgusage.setCancelable(false);
        btok = (Button)dgusage.findViewById(R.id.btok);

        btok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                startActivity(intent);
                dgusage.cancel();
            }
        });
    }
    boolean fetchstudent =true;
    public void initview() {
        initDialogs();
        Map<String, String> params = new HashMap<>();
        params.put("teacher_id", readFromPreference(this, PREF_WEB_ID, "0"));
        Fetchdata fe = new Fetchdata(this, url_student_details, params);
        fe.jsonResponse = this;
        fe.getData();
        fetchstudent = true;
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && !checkusageStatusEnabled()) {

            dgusage.show();
        }

        timeBankDao = daoSession.getTimeBankDao();
        tvtime = (TextView) findViewById(R.id.tvtime);
        btlogout = (Button) findViewById(R.id.btlogout);
        btCashout = (Button) findViewById(R.id.btCashout);
        if (!readFromPreference(this, PREF_CHILD_ID, "0").equals("0")) {
            StudentId = readFromPreference(this, PREF_CHILD_ID, "0");

            btlogout.setVisibility(View.VISIBLE);
        }
            /*Heshan*/
            btnPay = (Button) findViewById(R.id.btnPay);
            String showPay = readFromPreference(this, PREF_SHOW_PAY, "");
            if (showPay.equalsIgnoreCase("1")) {
                btnPay.setVisibility(View.VISIBLE);
            } else {
                btnPay.setVisibility(View.GONE);
            }
            /*--end--*/
            timeBankDao = daoSession.getTimeBankDao();
            tvtime = (TextView) findViewById(R.id.tvtime);
            btlogout = findViewById(R.id.btlogout);

            btCashout = (Button) findViewById(R.id.btCashout);
            if (!readFromPreference(this, PREF_CHILD_ID, "0").equals("0")) {
                StudentId = readFromPreference(this, PREF_CHILD_ID, "0");
                btlogout.setVisibility(View.VISIBLE);
                tvtime.setVisibility(View.VISIBLE);
                btCashout.setVisibility(View.VISIBLE);
                btlogout.setText("Logout " + readFromPreference(this, PREF_CHILD_NAME, "0"));
                selectTimebank();
                tvtime.setText(secondsToHrMinSec("" + currenttimebank));
            } else {
                btlogout.setVisibility(View.GONE);
                tvtime.setVisibility(View.GONE);
                btCashout.setVisibility(View.GONE);
            }
            RunService = true;
            savePreferences(HomeActivity.this, PREF_ECARROT_RUNNING, true);
            Intent intent = new Intent(HomeActivity.this, CheckUninstall.class);
            startService(intent);

            dgadminmenu = new Dialog(new ContextThemeWrapper(this, R.style.DialogSlideAnim));
            dgadminmenu.getWindow().setGravity(Gravity.BOTTOM);
            dgadminmenu.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dgadminmenu.setContentView(R.layout.dialog_admin_menu);

            tvoveride = (TextView) dgadminmenu.findViewById(R.id.tvoveride);
            tvcancel = (TextView) dgadminmenu.findViewById(R.id.tvcancel);
            tvuninstall = (TextView) dgadminmenu.findViewById(R.id.tvuninstall);
            tvAddChild = (TextView) dgadminmenu.findViewById(R.id.tvAddChild);
            tvReporting = (TextView) dgadminmenu.findViewById(R.id.tvReporting);
            tvusageReport = (TextView) dgadminmenu.findViewById(R.id.tvusageReport);
            tvmanagedestination = (TextView) dgadminmenu.findViewById(R.id.tvmanagedestination);
            tvreward = (TextView) dgadminmenu.findViewById(R.id.tvreward);
            tvUserAnalytics = (TextView) dgadminmenu.findViewById(R.id.tvUserAnalytics);
            tvlocklvl = (TextView) dgadminmenu.findViewById(R.id.tvlocklvl);
            dgaskpass = new Dialog(this);
            dgaskpass.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dgaskpass.setContentView(R.layout.dialog_check_pass);
            etPass = (EditText) dgaskpass.findViewById(R.id.etPass);
            btSubmit = (Button) dgaskpass.findViewById(R.id.btSubmit);
            tvfpass = (TextView) dgaskpass.findViewById(R.id.tvfpass);

            dialog_onClicks();
            createfpass();
        }

        void createfpass ()
        {
            dialogfpass = new Dialog(this);
            dialogfpass.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialogfpass.setContentView(R.layout.fpass);
            etdgemail = (EditText) dialogfpass.findViewById(R.id.etdgemail);
            btsend = (Button) dialogfpass.findViewById(R.id.btsend);

            btsend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fetchstudent = false;
                    String email = etdgemail.getText().toString();
                    //check if email address is correct format
                    if (checkEmail(email)) {
                        //send this information in the form of key and value format since we are using voley we use Map
                        Map<String, String> map = new HashMap<String, String>();
                        map.put("usr", email);
                        //   Fetchdata is the class under ConnectServer folder which is used to send data to the server.

                        Fetchdata ft = new Fetchdata(HomeActivity.this, url_sendpass1, map);
                        ft.getData();
                        //interface object is set for this fragment class so that once the data is received we get in below mentioned
                        // getdata method which is overrrinden from implemented class JSONResponse
                        ft.jsonResponse = HomeActivity.this;
                        dialogfpass.cancel();
                        showToast(HomeActivity.this, getString(R.string.email_has_sent));
                    } else {
                        showToast(HomeActivity.this, getString(R.string.invalid_email_address));
                    }
                }
            });

        }


        public void dialog_onClicks ()
        {

            tvlocklvl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeActivity.this, LockLevelActivity.class);
                    startActivity(intent);
                }
            });
            tvUserAnalytics.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(HomeActivity.this, SelectChildForAnalytics.class);
                    startActivity(intent);
                }
            });
            tvfpass.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dgaskpass.cancel();
                    dialogfpass.show();
                }
            });
            tvoveride.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("usr", readFromPreference(HomeActivity.this, PREF_EMAIL_ID, "dhiraj.ghorpade@gmail.com"));

                    if (!readFromPreference(HomeActivity.this, PREF_CHILD_ID, "0").equals("0")) {

                        map.put("studname", readFromPreference(HomeActivity.this, PREF_CHILD_NAME, "dhiraj.ghorpade@gmail.com"));

                    } else {
                        map.put("studname", "Admin");
                    }
                    map.put("date", "" + new SimpleDateFormat("yyyy-MMM-dd", Locale.getDefault()).format(new Date()));
                    DateFormat df = new SimpleDateFormat("h:mm a");

                    map.put("time", "" + df.format(Calendar.getInstance().getTime()));
                    Log.e("params", map.toString());


                    //   Fetchdata is the class under ConnectServer folder which is used to send data to the server.

                    Fetchdata ft = new Fetchdata(HomeActivity.this, url_admin_over, map);
                    ft.getData();

                    ft.jsonResponse = HomeActivity.this;
                    dialogfpass.cancel();
                    savePreferences(HomeActivity.this, PREF_ECARROT_RUNNING, false);
                    finish();
                    callhome(HomeActivity.this);
                }
            });
            tvAddChild.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    callNewActivity(HomeActivity.this, AddChildActivity.class);
                }
            });
            tvReporting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    usagereporting = false;
                    callNewActivity(HomeActivity.this, SelectStudentForReporting.class);
                }
            });
            tvusageReport.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // dgadminmenu.cancel();
                    usagereporting = true;
                    callNewActivity(HomeActivity.this, SelectStudentForReporting.class);
                }
            });
            btSubmit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (etPass.getText().toString().equals(readFromPreference(HomeActivity.this, PREF_PASSWORD, "0"))) {
                        if (open_Admin) {
                            dgaskpass.cancel();
                            dgadminmenu.show();
                        } else {
                            finish();
                            savePreferences(HomeActivity.this, PREF_ECARROT_RUNNING, false);
                            callhome(HomeActivity.this);
                            Intent intent = new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("http://ecarrot.nexva.com"));
                            startActivity(intent);

                        }

                    } else {
                        showToast(HomeActivity.this, getString(R.string.invalid_password));
                    }
                    etPass.setText("");
                }
            });
            tvuninstall.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    //Device admin set is activated through this code a settings screen appear from where the user can activate the device admin settings.
                    // for uninstall protection
                    // dgadminmenu.cancel();
                    if (readFromPreference(HomeActivity.this, PREF_DEVICE_ADMIN, "0").equals("0")) {
                        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);

                        ComponentName demoDeviceAdmin = new ComponentName(HomeActivity.this, DeviceAdmin.class);

                        Intent intent = new Intent(
                                DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);

                        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                                demoDeviceAdmin);
                        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                "Shabam needs permission to perform as Administrator.");
                        startActivity(intent);

                    } else {
                        showToast(HomeActivity.this, getString(R.string.uninstall_pro));
                    }
                }
            });
            tvmanagedestination.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bmanagedestination = true;
                    callNewActivity(HomeActivity.this, SelectChildForLogin.class);
                    // dgadminmenu.cancel();
                }
            });
            tvreward.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    callNewActivity(HomeActivity.this, RewardPenaltyTimeActivity.class);
                    //  dgadminmenu.cancel();
                }
            });
            tvcancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dgadminmenu.cancel();
                }
            });
        }



        public void selectTimebank ()
        {
            List lsttimebank = timeBankDao.queryBuilder().where(TimeBankDao.Properties.StudId.eq(StudentId)).list();
            if (lsttimebank.size() > 0) {
                TimeBank timeBank = (TimeBank) lsttimebank.get(0);
                currenttimebank = Long.parseLong(timeBank.getTimeBank());
            } else {
                TimeBank timeBank = new TimeBank();
                timeBank.setStudId("" + StudentId);
                timeBank.setTimeBank("" + 0);
                daoSession.insert(timeBank);
                currenttimebank = 0;
            }

        }


        public void eCarrot_Algorithm (View v)
        {
            if (!readFromPreference(this, PREF_CHILD_ID, "0").equals("0")) {
                callNewActivity(this, eCarrot_Algorithm.class);
            } else {

                callNewActivity(this, SelectChildForLogin.class);
            }

        }
        public void Logout_Click (View v)
        {
            saveToPreference(this, PREF_CHILD_NAME, "0");
            saveToPreference(this, PREF_CHILD_ID, "0");
            btlogout.setVisibility(View.GONE);
            btCashout.setVisibility(View.GONE);

            tvtime.setVisibility(View.GONE);
        }

        public void onPayClick (View view){
            callNewActivity_clear(this, PaymentActivity.class);
        }

        public void onLinkClick (View view){
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://ecarrot.nexva.com/"));
            startActivity(browserIntent);
        }

    @Override
    public void getData(JSONObject response) throws JSONException {
        if(fetchstudent) {
            child_dao = daoSession.getChild_DetailsDao();
            child_dao.deleteAll();
            //{"datas":[{"id":"3272","name":"dhi","age":"0"}]}
            if (response.getString("error123").equals("1")) {
                JSONArray ja = response.getJSONArray("datas");

                for (int i = 0; i < ja.length(); i++) {
                    JSONObject ch = ja.getJSONObject(i);
                    Child_Details item = new Child_Details();
                    item.setChild_id(ch.getString("id"));
                    item.setChild_name(ch.getString("name"));
                    daoSession.insert(item);
                }
            }
        }else{

        }
    }
}
