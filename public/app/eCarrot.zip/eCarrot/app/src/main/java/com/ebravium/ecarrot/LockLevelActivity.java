package com.ebravium.ecarrot;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_LOCK;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
public class LockLevelActivity extends AppCompatActivity {

    private TextView tvlockadd;
    private TextView tvlocksub;
    private TextView tvlockmul;
    private TextView tvlockdiv;
    private TextView tvunlock;
    private TextView addchk;
    private TextView subchk;
    private TextView mulchk;
    private TextView divchk;
    private TextView unlchk;

    public void initView()
    {
        tvlockadd =(TextView)findViewById(R.id.tvlockadd);
        tvlocksub =(TextView)findViewById(R.id.tvlocksub);
        tvlockmul =(TextView)findViewById(R.id.tvlockmul);
        tvlockdiv =(TextView)findViewById(R.id.tvlockdiv);
        tvunlock =(TextView)findViewById(R.id.tvunlock);
        addchk= (TextView)findViewById(R.id.addchk);
        subchk= (TextView)findViewById(R.id.subchk);
        mulchk= (TextView)findViewById(R.id.mulchk);
        divchk= (TextView)findViewById(R.id.divchk);
        unlchk= (TextView)findViewById(R.id.unlchk);

        tvlockadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveToPreference(LockLevelActivity.this,PREF_LOCK,"+");
                addchk.setVisibility(View.VISIBLE);
                mulchk.setVisibility(View.GONE);
                subchk.setVisibility(View.GONE);
                divchk.setVisibility(View.GONE);
                unlchk.setVisibility(View.GONE);
            }
        });
        tvlocksub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveToPreference(LockLevelActivity.this,PREF_LOCK,"-");
                subchk.setVisibility(View.VISIBLE);
                mulchk.setVisibility(View.GONE);
                addchk.setVisibility(View.GONE);
                divchk.setVisibility(View.GONE);
                unlchk.setVisibility(View.GONE);
            }
        });
        tvlockmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveToPreference(LockLevelActivity.this,PREF_LOCK,"*");
                mulchk.setVisibility(View.VISIBLE);
                addchk.setVisibility(View.GONE);
                subchk.setVisibility(View.GONE);
                divchk.setVisibility(View.GONE);
                unlchk.setVisibility(View.GONE);
            }
        });
        tvlockdiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveToPreference(LockLevelActivity.this,PREF_LOCK,"/");
                divchk.setVisibility(View.VISIBLE);
                mulchk.setVisibility(View.GONE);
                subchk.setVisibility(View.GONE);
                addchk.setVisibility(View.GONE);
                unlchk.setVisibility(View.GONE);
            }
        });

        tvunlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveToPreference(LockLevelActivity.this,PREF_LOCK,"0");
                unlchk.setVisibility(View.VISIBLE);
                mulchk.setVisibility(View.GONE);
                subchk.setVisibility(View.GONE);
                divchk.setVisibility(View.GONE);
                addchk.setVisibility(View.GONE);
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_level);
        initView();
        if(readFromPreference(this,PREF_LOCK,"0").equals("+")){
            addchk.setVisibility(View.VISIBLE);
        }
        if(readFromPreference(this,PREF_LOCK,"0").equals("-")){
            subchk.setVisibility(View.VISIBLE);
        }
        if(readFromPreference(this,PREF_LOCK,"0").equals("*")){
            mulchk.setVisibility(View.VISIBLE);
        }
        if(readFromPreference(this,PREF_LOCK,"0").equals("/")){
            divchk.setVisibility(View.VISIBLE);
        }
        if(readFromPreference(this,PREF_LOCK,"0").equals("0")){
            unlchk.setVisibility(View.VISIBLE);
        }

    }
}
