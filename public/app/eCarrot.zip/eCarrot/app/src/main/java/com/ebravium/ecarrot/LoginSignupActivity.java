package com.ebravium.ecarrot;

import android.app.Dialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.ebravium.ecarrot.Adapters.ViewPagerAdapter;
import com.ebravium.ecarrot.TabLayout.SlidingTabLayout;

import java.util.ArrayList;
import java.util.List;

public class LoginSignupActivity extends AppCompatActivity {
    private ViewPagerAdapter adapter;
    private ViewPager pager;
    private SlidingTabLayout tabs;
    private Dialog dglauncher;
    private Button btok;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_signup);
        CharSequence   Titles[]={getString(R.string.sign_in),getString(R.string.sign_up)};
        adapter =  new ViewPagerAdapter(getSupportFragmentManager(),Titles,2);

        // Assigning ViewPager View and setting the adapter
        pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(adapter);

        // Assiging the Sliding Tab Layout View
        tabs = (SlidingTabLayout) findViewById(R.id.tabs);

        tabs.setDistributeEvenly(true); // To make the Tabs Fixed set this true, This makes the tabs Space Evenly in Available width


        // Setting the ViewPager For the SlidingTabsLayout
        tabs.setViewPager(pager);
        dglauncher = new Dialog(this);
        dglauncher.setCancelable(false);
        dglauncher.setContentView(R.layout.launchersetactivity);
        btok = (Button)dglauncher.findViewById(R.id.btlaunchok);
        btok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent selector = new Intent(Intent.ACTION_MAIN);
                selector.addCategory(Intent.CATEGORY_HOME);
                selector.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(selector);
             dglauncher.cancel();
            }
        });
      /*  if(!isMyLauncherDefault())
        {
            dglauncher.show();
        }*/

    }
    boolean isMyLauncherDefault() {
        final IntentFilter filter = new IntentFilter(Intent.ACTION_MAIN);
        filter.addCategory(Intent.CATEGORY_HOME);

        List<IntentFilter> filters = new ArrayList<IntentFilter>();
        filters.add(filter);

        final String myPackageName = getPackageName();
        List<ComponentName> activities = new ArrayList<ComponentName>();
        final PackageManager packageManager = (PackageManager) getPackageManager();

        // You can use name of your package here as third argument
        packageManager.getPreferredActivities(filters, activities, null);

        for (ComponentName activity : activities) {
            if (myPackageName.equals(activity.getPackageName())) {
                return true;
            }
        }
        return false;
    }
}
