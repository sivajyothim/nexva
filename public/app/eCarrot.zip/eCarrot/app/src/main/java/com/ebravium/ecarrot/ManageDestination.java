package com.ebravium.ecarrot;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.ebravium.ecarrot.Adapters.AppListAdapter;
import com.ebravium.ecarrot.Common.AppList;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.ManageDestinationApp;
import com.ebravium.ecarrot.model.ManageDestinationAppDao;
import com.ebravium.ecarrot.model.ReportingDao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ManageDestination extends AppCompatActivity {
    private ListView lstapplist;
    private AppListAdapter myAdapter;
    private ArrayList<AppList> arrapplst;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private ManageDestinationAppDao desti_dao;
    private String child_id="1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_destination);
        arrapplst=new ArrayList<AppList>();
        lstapplist = (ListView)findViewById(R.id.lstapplist);
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        desti_dao = daoSession.getManageDestinationAppDao();
        child_id= getIntent().getStringExtra("chdid");
        getinstallapp();
    }
    public void getinstallapp(){
        arrapplst.clear();
        final PackageManager pm = getPackageManager();
        Intent main=new Intent(Intent.ACTION_MAIN, null);

        main.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> apps =pm.queryIntentActivities(main, 0);;





        String check="AS";
        for (int i = 0; i < apps.size(); i++) {

            if(apps.get(i).activityInfo.packageName.toString().contains("com.hashtag")||apps.get(i).activityInfo.packageName.toString().contains("com.ebravium")||apps.get(i).activityInfo.packageName.toString().equals("com.android.settings")){

            }else
            {
                String packagename = apps.get(i).activityInfo.packageName.toString();
                if(packagename.equals(check))
                {

                }else
                {
                    check=packagename;

                    String appname=""+pm.getApplicationLabel(apps.get(i).activityInfo.applicationInfo);

                    Drawable icon =apps.get(i).activityInfo.applicationInfo.loadIcon(pm);
                    String statelock="2";


                    AppList applst = new AppList();
                    appname=(Character.toUpperCase(appname.charAt(0)) + appname.substring(1).toLowerCase()).trim();
                    applst.setAppname(appname);
                    applst.setPkgname(packagename);

                    applst.setLockunlock(statelock);

                    applst.icon=icon;
                    String SQL_APP_IN_DATABASE = "SELECT "+ManageDestinationAppDao.Properties.Status.columnName+" From "  + ManageDestinationAppDao.TABLENAME + " where " + ManageDestinationAppDao.Properties.ChildId.columnName + " = '" + child_id + "' AND " + ManageDestinationAppDao.Properties.PackageName.columnName + " = '" + packagename + "'";
                    Cursor cur = daoSession.getDatabase().rawQuery(SQL_APP_IN_DATABASE, null);
                    if(cur.getCount()>0){
                        cur.moveToFirst();
                        Log.e("ColumnCount", ""+ cur.getString(0));

                      statelock=  cur.getString(0);
                    }else{
                        ManageDestinationApp app= new ManageDestinationApp();
                        app.setAppName(appname);
                        app.setChildId(child_id);
                        app.setPackageName(packagename);
                        app.setStatus(statelock);
                        desti_dao.insert(app);
                    }

                    applst.setLockunlock(statelock);
                    applst.setId(child_id);
                    arrapplst.add(applst);

                }
            }
        }


        Collections.sort(arrapplst, new Comparator<AppList>(){
            public int compare(AppList obj1, AppList obj2)
            {
                return obj1.getAppname().compareToIgnoreCase(obj2.getAppname());
            }
        });
        //Log.e("list",arrapplst.toString());
        myAdapter = new AppListAdapter(this, arrapplst);
        myAdapter.notifyDataSetChanged();
        lstapplist.setAdapter(myAdapter);

    }

}
