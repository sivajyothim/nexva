package com.ebravium.ecarrot;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.ebravium.ecarrot.Common.CommonFuctions;
import com.ebravium.ecarrot.Common.eCarrotConstants;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.Parent_Login;
import com.ebravium.ecarrot.model.Parent_LoginDao;

import java.util.List;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_SHOW_PAY;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;

/* added by Heshan */
public class PaymentActivity extends AppCompatActivity {

    private WebView webView;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        init();
    }

    View.OnClickListener dismissListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            callNewActivity_clear(PaymentActivity.this, SplashScreen.class);
        }
    };

    View.OnClickListener reTryListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            getUserDetails();
        }
    };

    /*
    * init
    * */
    @SuppressLint("SetJavaScriptEnabled")
    private void init() {
        webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);

        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(PaymentActivity.this,
                "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
    }

    @Override
    protected void onResume() {
        super.onResume();

        getUserDetails();
    }

    /*
    * request
    * */
    //get admin email
    private void getUserDetails() {

        try {
            String email = null;
            Parent_LoginDao parent_loginDao = daoSession.getParent_LoginDao();
            List<Parent_Login> parent_logins = parent_loginDao.loadAll();

            if (parent_logins.size() > 0) {
                email = parent_logins.get(0).getEmail();
                if (email != null && !email.isEmpty()) {
                    CommonFuctions.showProgressDialog(this, "Loading paypal...");
                    loadPayPal(email);
                } else {
                    CommonFuctions.alertUser(this,
                            getResources().getString(R.string.alert_common_failed), dismissListener);
                }
            } else {
                CommonFuctions.alertUser(this,
                        getResources().getString(R.string.alert_common_failed), dismissListener);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //open Paypal web view in order to proceed with payments
    private void loadPayPal(String email) {

        String userId = readFromPreference(this, PREF_WEB_ID, "");
        String url = eCarrotConstants.URL_PAYMENT.concat("currency_code/")
                .concat(eCarrotConstants.CURRENCY_CODE).concat("product_price/0.01/email/")
                .concat(email).concat("/user_id/").concat(userId);

        webView.setWebViewClient(new WebViewClient() {
            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(PaymentActivity.this, description, Toast.LENGTH_SHORT).show();
            }
            @TargetApi(android.os.Build.VERSION_CODES.M)
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError rerr) {
                // Redirect to deprecated method, so you can use it in all SDK versions
                onReceivedError(view, rerr.getErrorCode(), rerr.getDescription().toString(), req.getUrl().toString());
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.e("onPageStarted", url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.e("onPageFinished", url);
                CommonFuctions.hideProgressDialog();
                if (url.equalsIgnoreCase("http://api.nexva.com/ecarrot/success")) {
                    proceed();
                } else if (url.equalsIgnoreCase("http://api.nexva.com/ecarrot/error")) {
                    CommonFuctions.alertPayment(PaymentActivity.this,
                            getResources().getString(R.string.payment_fail),
                            reTryListener,
                            dismissListener,
                            "TRY AGAIN",
                            "CONTINUE WITH FREE TRIAL");
                } else if (url.contains("http://api.nexva.com/ecarrot/cancel")) {
                    showError(R.string.alert_subscription);
                }
            }
        });
        webView.loadUrl(url);
    }

    private void proceed() {
        saveToPreference(this, PREF_SHOW_PAY,"0");
        CommonFuctions.alertUser(this, getResources().getString(R.string.payment_success),
                dismissListener);
    }

    private void showError(int message) {
        CommonFuctions.alertUser(this, getResources().getString(message),
                dismissListener);
    }
}
