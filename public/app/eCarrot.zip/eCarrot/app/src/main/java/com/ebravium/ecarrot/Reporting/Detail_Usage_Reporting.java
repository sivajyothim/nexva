package com.ebravium.ecarrot.Reporting;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.ebravium.ecarrot.Adapters.UsageDetailReport;
import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.TimeUsageDetails;
import com.ebravium.ecarrot.model.TimeUsageDetailsDao;
import com.ebravium.ecarrot.model.Usage_detailDao;

import java.util.ArrayList;

public class Detail_Usage_Reporting extends AppCompatActivity {

    private ListView lstdetail;
    private String StudentId;
    private String date;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
ArrayList<TimeUsageDetails>arrayList = new ArrayList<>();
    private String appname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail__usage__reporting);
        lstdetail = (ListView)findViewById(R.id.lstdetail);
        StudentId=getIntent().getStringExtra("chdid");
        date =getIntent().getStringExtra("date");
        appname =getIntent().getStringExtra("appname");
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        arrange_usage_report();
    }

    public void arrange_usage_report() {
        //  Usage_detailDao cd = daoSession.getUsage_detailDao();

        String SQL_REPORTING_DATA = "SELECT * " + " FROM " + TimeUsageDetailsDao.TABLENAME + " where " +
                TimeUsageDetailsDao.Properties.ChildId.columnName + " = '" + StudentId +
                "' AND " + TimeUsageDetailsDao.Properties.Date.columnName + " = '" + date + "' AND "+
                TimeUsageDetailsDao.Properties.AppName.columnName+" = '"+appname+"'";
        Log.e("Query",SQL_REPORTING_DATA);

        Cursor cur = daoSession.getDatabase().rawQuery(SQL_REPORTING_DATA, null);
        while (cur.moveToNext())
        {
            TimeUsageDetails item = new TimeUsageDetails();
            item.setAppName(cur.getString(cur.getColumnIndex(TimeUsageDetailsDao.Properties.AppName.columnName)));
            item.setDate(cur.getString(cur.getColumnIndex(TimeUsageDetailsDao.Properties.Date.columnName)));
            item.setPackageName(cur.getString(cur.getColumnIndex(TimeUsageDetailsDao.Properties.PackageName.columnName)));
            item.setStartTime(cur.getString(cur.getColumnIndex(TimeUsageDetailsDao.Properties.StartTime.columnName)));
            item.setStopTime(cur.getString(cur.getColumnIndex(TimeUsageDetailsDao.Properties.StopTime.columnName)));
            arrayList.add(item);
        }
        Log.e("Count",""+arrayList.size());
        UsageDetailReport adapter = new UsageDetailReport(this,arrayList);
        lstdetail.setAdapter(adapter);
    }
    }
