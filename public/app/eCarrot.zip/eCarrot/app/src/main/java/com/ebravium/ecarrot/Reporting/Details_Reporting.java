package com.ebravium.ecarrot.Reporting;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.ebravium.ecarrot.Adapters.ReportingAdapter;
import com.ebravium.ecarrot.Common.DetailReporting;
import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.ReportingDao;

import java.util.ArrayList;

public class Details_Reporting extends AppCompatActivity {

    private String StudentId;
    private String session;
    private String date;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
ArrayList<DetailReporting> arrreport;
    private ListView lstdetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details__reporting);
        initview();
    }
    public void initview()
    {
        arrreport= new ArrayList<>();
        StudentId = getIntent().getStringExtra("StudentId");
        session=getIntent().getStringExtra("session");
        date=getIntent().getStringExtra("date");
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        lstdetail= (ListView)findViewById(R.id.lstdetail);
        arrangeinList();
    }
    public void arrangeinList(){
        String SQL_REPORTING_DATA="SELECT * " + " FROM " + ReportingDao.TABLENAME + " where " + ReportingDao.Properties.StudentId.columnName + " = '" + StudentId + "' AND "+ReportingDao.Properties.Date.columnName+" = '"+date+"' AND "+ReportingDao.Properties.SessionId.columnName+" = '"+session+"'";
        Cursor cur = daoSession.getDatabase().rawQuery(SQL_REPORTING_DATA, null);
        while(cur.moveToNext())
        {
            DetailReporting dpr= new DetailReporting();
            dpr.setAnswerGiven(cur.getString(cur.getColumnIndex(ReportingDao.Properties.Answer.columnName)));
            dpr.setExpectedAnswer(cur.getString(cur.getColumnIndex(ReportingDao.Properties.ExpectedAnswer.columnName)));
            dpr.setQuestion(cur.getString(cur.getColumnIndex(ReportingDao.Properties.Question.columnName)));
            if(cur.getString(cur.getColumnIndex(ReportingDao.Properties.Status.columnName)).equals("1"))
                dpr.setStatus("Correct");
            else
                dpr.setStatus("InCorrect");

            float timetaken= Float.parseFloat(cur.getString(cur.getColumnIndex(ReportingDao.Properties.TimeTaken.columnName)))/1000;
            String time = ""+timetaken;
            dpr.setTimeTaken(""+time.substring(0,time.indexOf(".")+2)+" Sec");
            arrreport.add(dpr);

        }
        ReportingAdapter adapter = new ReportingAdapter(this,arrreport);
        lstdetail.setAdapter(adapter);

    }
}
