package com.ebravium.ecarrot.Reporting;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.ReportingDao;

public class SummaryReport extends AppCompatActivity {

    private String date;
    private String StudentId;
    private String session;
    private TextView tvavgcorrect;
    private TextView tvavgincorrect;
    private TextView tvnumcorrect;
    private TextView tvnumincorrect;


    private Button btdetails;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
int correct=0;
    int incorrect=0;
            int timetakenCorrect=0;
    int getTimetakeninCorrect=0;
    float avgtimetakencorrect=0;
    float avgtimetakenincorrect=0;
    private TextView tvspeedcor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary_report);
        initview();
    }
    public void initview(){
        StudentId = getIntent().getStringExtra("StudentId");
        session=getIntent().getStringExtra("session");
        date=getIntent().getStringExtra("date");
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        tvavgcorrect=  (TextView)findViewById(R.id.tvavgcorrect);
        tvavgincorrect=  (TextView)findViewById(R.id.tvavgincorrect);
        tvnumcorrect=  (TextView)findViewById(R.id.tvnumcorrect);
        tvnumincorrect=  (TextView)findViewById(R.id.tvnumincorrect);
        btdetails  =(Button)findViewById(R.id.btdetails);
        tvspeedcor =(TextView)findViewById(R.id.tvspeedcor);
        getDetails();

    }

    public void getDetails(){
        String SQL_REPORTING_DATA="SELECT * " + " FROM " + ReportingDao.TABLENAME + " where " + ReportingDao.Properties.StudentId.columnName + " = '" + StudentId + "' AND "+ReportingDao.Properties.Date.columnName+" = '"+date+"' AND "+ReportingDao.Properties.SessionId.columnName+" = "+session;
        Cursor cur = daoSession.getDatabase().rawQuery(SQL_REPORTING_DATA, null);
        while(cur.moveToNext())
        {
            if(cur.getString(cur.getColumnIndex(ReportingDao.Properties.Status.columnName)).equals("1")){
                correct+=1;
                timetakenCorrect+= Integer.parseInt(cur.getString(cur.getColumnIndex(ReportingDao.Properties.TimeTaken.columnName)));
            }else{
                incorrect+=1;
                getTimetakeninCorrect+= Integer.parseInt(cur.getString(cur.getColumnIndex(ReportingDao.Properties.TimeTaken.columnName)));

            }
        }
        if(correct!=0) {
            avgtimetakencorrect = timetakenCorrect / correct;
            avgtimetakencorrect = avgtimetakencorrect /1000 ;
        }
        if(incorrect!=0){
            avgtimetakenincorrect = getTimetakeninCorrect / incorrect;
            avgtimetakenincorrect = avgtimetakenincorrect /1000;
        }
        float tmt = (float)timetakenCorrect;
float minutesspent = tmt/60000;
        Log.e("Miute",""+minutesspent);
        String speed =""+correct/minutesspent;
        speed = speed.substring(0,speed.indexOf("."));

        tvavgcorrect.setText(""+avgtimetakencorrect);
        tvavgincorrect.setText(""+avgtimetakenincorrect);
        tvnumcorrect.setText(""+correct);
        tvnumincorrect.setText(""+incorrect);
        tvspeedcor.setText(""+speed);
    }

   public void btdetails_click(View v){

       Intent intent = new Intent(SummaryReport.this,Details_Reporting.class);
       intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
       intent.putExtra("StudentId",StudentId);
       intent.putExtra("date",date);
       intent.putExtra("session",""+session);
       startActivity(intent);
   }
}
