package com.ebravium.ecarrot.Reporting;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.ReportingDao;
import com.ebravium.ecarrot.model.TimeBank;
import com.ebravium.ecarrot.model.TimeBankDao;
import com.ebravium.ecarrot.model.TimeSpendOutSide;
import com.ebravium.ecarrot.model.TimeSpendOutSideDao;

import java.util.List;

import static com.ebravium.ecarrot.Common.CommonFuctions.secondsToHrMinSec;
import static com.ebravium.ecarrot.Common.eCarrotConstants.StudentId;
import static com.ebravium.ecarrot.Common.eCarrotConstants.earntime;
import static com.ebravium.ecarrot.Common.eCarrotConstants.timeBankDao;

public class UserAnalytics extends AppCompatActivity {

    private String StudentId;
    private String session;
    private String date;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    int timeSpendEarning=0;
    int timeSpendOutside=0;
    private TextView tvtimearn;
    private TextView tvoutside;
    private TextView tvtimearned;
    private TextView tvfirstcashout;
    private TextView tvcurrenttimebank;
    private String startTimeBank;
    private TextView tvtimesused;
    private int times=0;
    private TextView tvworkreward;
    private TextView tvworkplay;

    public long selectTimebank() {
        List lsttimebank = timeBankDao.queryBuilder().where(TimeBankDao.Properties.StudId.eq(StudentId)).list();
        if (lsttimebank.size() > 0) {
            TimeBank timeBank = (TimeBank) lsttimebank.get(0);
            earntime = Long.parseLong(timeBank.getTimeBank());
        } else {
            TimeBank timeBank = new TimeBank();
            timeBank.setStudId("" + StudentId);
            timeBank.setTimeBank("" + 0);
            daoSession.insert(timeBank);
            earntime = 0;
        }
        return earntime;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_analytics);
        StudentId = getIntent().getStringExtra("stdid");
        session=getIntent().getStringExtra("session");
        date=getIntent().getStringExtra("date");
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        timeBankDao = daoSession.getTimeBankDao();
        tvtimearn=(TextView)findViewById(R.id.tvtimearn);
        tvoutside=(TextView)findViewById(R.id.tvoutside);
        tvtimearned=(TextView)findViewById(R.id.tvtimearned);
        tvfirstcashout=(TextView)findViewById(R.id.tvfirstcashout);
        tvcurrenttimebank=(TextView)findViewById(R.id.tvcurrenttimebank);
        tvtimesused=(TextView)findViewById(R.id.tvtimesused);
        tvworkreward=(TextView)findViewById(R.id.tvworkreward);
        tvworkplay=(TextView)findViewById(R.id.tvworkplay);
        getDetails();
        tvoutside.setText(secondsToHrMinSec(""+(timeSpendOutside)));
        tvtimearn.setText(secondsToHrMinSec(""+timeSpendEarning));
        Log.e("TotalTimeEarned",""+TotalTime);
        int gc=0;
        if(TotalTime<=0||timeSpendEarning==0)
            tvworkreward.setText("0");
        else{

            gc = gcd(TotalTime,timeSpendEarning);
            int num=TotalTime/gc;
            int den =timeSpendEarning/gc;
            Log.e("TimeRatio",TotalTime+"  "+timeSpendEarning+"  "+num+":"+den);
            tvworkreward.setText(num+":"+den);
        }


        if(timeSpendOutside<=0||timeSpendEarning==0)
            tvworkplay.setText("0");
        else{

            gc = gcd(timeSpendEarning,timeSpendOutside);
            int den=timeSpendOutside/gc;
            int num =timeSpendEarning/gc;
            Log.e("TimeRatio",timeSpendOutside+"  "+timeSpendEarning+"  "+num+":"+den);
            tvworkplay.setText(num+":"+den);
        }

        tvtimearned.setText(secondsToHrMinSec(""+TotalTime));
        tvfirstcashout.setText(secondsToHrMinSec(startTimeBank));
        tvcurrenttimebank.setText(secondsToHrMinSec(""+selectTimebank()));
        tvtimesused.setText(""+times);
    }
    int gcd(int p, int q) {
        if (q == 0) return p;
        else return gcd(q, p % q);
    }
    int temptime=0,TotalTime=0;
    public void getDetails() {
        String SQL_REPORTING_DATA = "SELECT * " + " FROM " + ReportingDao.TABLENAME + " where " +
                ReportingDao.Properties.StudentId.columnName + " = '" + StudentId + "' AND " +
                ReportingDao.Properties.Date.columnName + " = '" + date + "'";
        Log.e("Query",SQL_REPORTING_DATA);
        Cursor cur = daoSession.getDatabase().rawQuery(SQL_REPORTING_DATA, null);
        int ses=0;
        String start_time="0",stop_time="0";
        while (cur.moveToNext())
        {
            int curses = Integer.parseInt(cur.getString(cur.getColumnIndex(ReportingDao.Properties.SessionId.columnName)));


            if(ses==curses)
            {
                temptime=Integer.parseInt(cur.getString(cur.getColumnIndex(ReportingDao.Properties.TimeEarned.columnName)));
            }
            if(ses!=curses)
            {
                ses =curses;
                TotalTime+=temptime;
            }
    Log.e("TempTime",""+temptime);

            start_time= cur.getString(cur.getColumnIndex(ReportingDao.Properties.StartTime.columnName));
            stop_time= cur.getString(cur.getColumnIndex(ReportingDao.Properties.StopTime.columnName));
            timeSpendEarning+=Long.parseLong(stop_time)-Long.parseLong(start_time);

        }
        TotalTime+=temptime;

        String SQL_REPORTING_DATA1 = "SELECT * " + " FROM " + TimeSpendOutSideDao.TABLENAME + " where " +
                TimeSpendOutSideDao.Properties.ChildId.columnName + " = '" + StudentId + "' AND " +
                TimeSpendOutSideDao.Properties.Date.columnName + " = '" + date + "'";
        Log.e("Query",SQL_REPORTING_DATA);
        Cursor cur1 = daoSession.getDatabase().rawQuery(SQL_REPORTING_DATA1, null);

        String start_time1="0",stop_time1="0";
        Log.e("Query",""+cur1.getCount());
        while (cur1.moveToNext())
        {
            int zerotimebank = Integer.parseInt(cur1.getString(cur1.getColumnIndex(TimeSpendOutSideDao.Properties.ZeroTimeBank.columnName)));
            if(zerotimebank==1)
                times+=1;
            start_time1= cur1.getString(cur1.getColumnIndex(TimeSpendOutSideDao.Properties.StartTime.columnName));
            stop_time1= cur1.getString(cur1.getColumnIndex(TimeSpendOutSideDao.Properties.StopTime.columnName));
            timeSpendOutside+=Long.parseLong(stop_time1)-Long.parseLong(start_time1);
            Log.e("timeSpendOutside",start_time1+ "  "+timeSpendOutside+"  "+stop_time1);

        }
        if(cur1.getCount()>0)
        {
            cur1.moveToFirst();
            startTimeBank= cur1.getString(cur1.getColumnIndex(TimeSpendOutSideDao.Properties.TimeBankStatusBefore.columnName));

        }
        timeSpendEarning=timeSpendEarning/1000;
        timeSpendOutside=timeSpendOutside/1000;

    }
}
