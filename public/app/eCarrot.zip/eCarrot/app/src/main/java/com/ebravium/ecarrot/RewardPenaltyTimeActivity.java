package com.ebravium.ecarrot;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_2_SEC;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_4_SEC;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_5_SEC;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PENALTY;

public class RewardPenaltyTimeActivity extends AppCompatActivity {

    private EditText et2sec,et4sec,et5sec,etpen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reward_penalty_time);
        initview();
    }
    public void initview()
    {
        et2sec =(EditText)findViewById(R.id.et2sec);
        et4sec =(EditText)findViewById(R.id.et4sec);
        et5sec =(EditText)findViewById(R.id.et5sec);
        etpen =(EditText)findViewById(R.id.etpen);
        et2sec.setText(readFromPreference(this,PREF_2_SEC,"30"));
        et4sec.setText(readFromPreference(this,PREF_4_SEC,"20"));
        et5sec.setText(readFromPreference(this,PREF_5_SEC,"10"));
        etpen.setText(readFromPreference(this,PREF_PENALTY,"10"));

    }
    public void Submit_Click(View v)
    {
        String sec2 = et2sec.getText().toString();
        String sec4 = et4sec.getText().toString();
        String sec5 = et5sec.getText().toString();
        String secpen = etpen.getText().toString();
        if(isInteger(sec2)&&isInteger(sec4)&&isInteger(sec5)&&isInteger(secpen))
        {
            saveToPreference(this,PREF_2_SEC,sec2);
            saveToPreference(this,PREF_4_SEC,sec4);
            saveToPreference(this,PREF_5_SEC,sec5);
            saveToPreference(this,PREF_PENALTY,secpen);
            showToast(this,getString(R.string.reward_pen));
        }else{
            showToast(this,getString(R.string.only_integer_value));
        }
    }

    public boolean isInteger(String text)
    {
        try {
            int num = Integer.parseInt(text);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
