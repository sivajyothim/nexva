package com.ebravium.ecarrot;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ebravium.ecarrot.Adapters.ChildNameAdapter;
import com.ebravium.ecarrot.R;
import com.ebravium.ecarrot.Reporting.SelectStudentForReporting;
import com.ebravium.ecarrot.Reporting.SummaryReport;
import com.ebravium.ecarrot.Reporting.UserAnalytics;
import com.ebravium.ecarrot.model.Child_Details;
import com.ebravium.ecarrot.model.Child_DetailsDao;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.ReportingDao;
import com.ebravium.ecarrot.model.TimeUsageDetailsDao;

import java.util.ArrayList;
import java.util.List;

import static com.ebravium.ecarrot.Common.eCarrotConstants.usagereporting;

public class SelectChildForAnalytics extends AppCompatActivity {

    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private ListView lvstudlist;
    ArrayList<String> lstdates;
    private ArrayAdapter<String> adapter;
    private Dialog dgdates;
    private ListView lstviewdates;
    private List<Child_Details> lstchd;
    private String StudentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_child_for_analytics);
        initview();
    }

    public void initview() {
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        lvstudlist = (ListView) findViewById(R.id.lvstudlist);
        arrange_child_list();

        lstdates = new ArrayList<>();

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lstdates);


        dgdates = new Dialog(this);
        dgdates.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dgdates.setContentView(R.layout.dialog_dates_reporting);
        lstviewdates = (ListView) dgdates.findViewById(R.id.lstdates);


        lstviewdates.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(SelectChildForAnalytics.this, UserAnalytics.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("stdid", StudentId);
                intent.putExtra("date", lstdates.get(position));
                startActivity(intent);
                finish();

            }
        });

        lvstudlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Child_Details chd = lstchd.get(position);
                lstdates.clear();
                StudentId = chd.getChild_id();
                setdates(StudentId);
                    dgdates.show();

            }
        });
    }

    public void arrange_child_list()
    {
        Child_DetailsDao cd = daoSession.getChild_DetailsDao();
        lstchd=cd.loadAll();
        ChildNameAdapter adapter = new ChildNameAdapter(this,lstchd);
        lvstudlist.setAdapter(adapter);


    }
    public void setdates(String chdid)
    {

        String SQL_DISTINCT_ENAME = "SELECT DISTINCT " + ReportingDao.Properties.Date.columnName + " FROM " +
                ReportingDao.TABLENAME + " where " + ReportingDao.Properties.StudentId.columnName + " = '" + chdid + "'";
        Cursor cur = daoSession.getDatabase().rawQuery(SQL_DISTINCT_ENAME, null);

        while (cur.moveToNext()) {
            lstdates.add(cur.getString(0));
        }
        adapter.notifyDataSetChanged();
        lstviewdates.setAdapter(adapter);
    }

    }
