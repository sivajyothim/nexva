package com.ebravium.ecarrot;

import android.app.Dialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.ebravium.ecarrot.Adapters.ChildNameAdapter;
import com.ebravium.ecarrot.model.Child_Details;
import com.ebravium.ecarrot.model.Child_DetailsDao;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_CHILD_ID;

import java.net.NoRouteToHostException;
import java.util.List;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_CHILD_NAME;
import static com.ebravium.ecarrot.Common.eCarrotConstants.bmanagedestination;


public class SelectChildForLogin extends AppCompatActivity {

    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private ListView lvstudlist;
    private ChildNameAdapter adapter;
    private List<Child_Details> lstchd;
    private EditText etPass;
    private Button btsubmit;
    public Child_Details chd;
    private Dialog dgAddChild;
    private Button btok;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_child_for_login);
        initview();
    }

    public void  initview()
    {
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        lvstudlist=(ListView)findViewById(R.id.lvstudlist);

        lvstudlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(!bmanagedestination) {
                    chd = lstchd.get(position);
                    saveToPreference(SelectChildForLogin.this,PREF_CHILD_ID,chd.getChild_id());
                    saveToPreference(SelectChildForLogin.this,PREF_CHILD_NAME,chd.getChild_name());
                    callNewActivity(SelectChildForLogin.this,eCarrot_Algorithm.class);
                    finish();
                }else{


                    bmanagedestination=false;
                    chd = lstchd.get(position);
                    Intent intent = new Intent(SelectChildForLogin.this,ManageDestination.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("chdid",chd.getChild_id());
                    startActivity(intent);
                    finish();
                }
            }
        });
        arrange_child_list();
    }
    public void arrange_child_list()
    {
        Child_DetailsDao cd = daoSession.getChild_DetailsDao();
        lstchd=cd.loadAll();
        if(lstchd.size()==0)
        {
            initDialogs();
        }
        if(lstchd.size()==1)
        {
            if(!bmanagedestination) {
                chd = lstchd.get(0);
                saveToPreference(SelectChildForLogin.this,PREF_CHILD_ID,chd.getChild_id());
                saveToPreference(SelectChildForLogin.this,PREF_CHILD_NAME,chd.getChild_name());
                callNewActivity(SelectChildForLogin.this,eCarrot_Algorithm.class);
                finish();
            }else{


                bmanagedestination=false;
                chd = lstchd.get(0);
                Intent intent = new Intent(SelectChildForLogin.this,ManageDestination.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("chdid",chd.getChild_id());
                startActivity(intent);
                finish();
            }
        }
        ChildNameAdapter adapter = new ChildNameAdapter(this,lstchd);
        lvstudlist.setAdapter(adapter);


    }

    public void initDialogs()
    {

        dgAddChild= new Dialog(this);
        dgAddChild.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dgAddChild.setContentView(R.layout.addchildinfo);
        dgAddChild.setCancelable(false);
        btok = (Button)dgAddChild.findViewById(R.id.btok);

        btok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectChildForLogin.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
        dgAddChild.show();
    }
}
