package com.ebravium.ecarrot.Services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.util.Log;

import com.ebravium.ecarrot.SplashScreen;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.TimeBank;
import com.ebravium.ecarrot.model.TimeBankDao;
import com.ebravium.ecarrot.model.TimeSpendOutSide;
import com.ebravium.ecarrot.model.TimeSpendOutSideDao;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity;
import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.savePreferences;
;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_CHILD_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_RUNNING;

import static com.ebravium.ecarrot.Common.eCarrotConstants.StudentId;
import static com.ebravium.ecarrot.Common.eCarrotConstants.daoSessiontime;
import static com.ebravium.ecarrot.Common.eCarrotConstants.earntime;
import static com.ebravium.ecarrot.Common.eCarrotConstants.objcaltime;
import static com.ebravium.ecarrot.Common.eCarrotConstants.startTimeBank;
import static com.ebravium.ecarrot.Common.eCarrotConstants.startcountdown;
import static com.ebravium.ecarrot.Common.eCarrotConstants.startedtimer;
import static com.ebravium.ecarrot.Common.eCarrotConstants.stopTimeBank;
import static com.ebravium.ecarrot.Common.eCarrotConstants.stopcountdown;
import static com.ebravium.ecarrot.Common.eCarrotConstants.timeBankDao;

public class CalUseEarnTime extends Service {


    private CountDownTimer mCountDownTimer;/*Checks if CountdownTimer is still working or not*/


    private long intial_earntime = 0;

    private int counter = 0;
    private Context con;

    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;



    public long selectTimebank() {
        List lsttimebank = timeBankDao.queryBuilder().where(TimeBankDao.Properties.StudId.eq(StudentId)).list();
        if (lsttimebank.size() > 0) {
            TimeBank timeBank = (TimeBank) lsttimebank.get(0);
            earntime = Long.parseLong(timeBank.getTimeBank());
        } else {
            TimeBank timeBank = new TimeBank();
            timeBank.setStudId("" + StudentId);
            timeBank.setTimeBank("" + 0);
            daoSession.insert(timeBank);
            earntime = 0;
        }
        return earntime;
    }

    public void stoptimer() {

        if (startedtimer) {
            startedtimer = false;
            if (mCountDownTimer != null) {

                mCountDownTimer.cancel();
            }

            UsageDetail(0);
        }
    }

    public void MyTime2(final Context con) {
        Log.e("mili",""+earntime);
        long mili = (earntime + 1) * 1000;

        intial_earntime = earntime;

//countdown time r start here and starts counting and updating the database with the timebank status and in the end calls back splashscreen activity...
        mCountDownTimer = new CountDownTimer(mili, 1000) {


            @Override
            public void onFinish() {

                startedtimer = false;


                saveTimebank();
                savePreferences(con, PREF_ECARROT_RUNNING, true);
                callNewActivity(con, SplashScreen.class);
                stopTimeBank=0;
                UsageDetail(1);
            }

            public void onTick(long millisUntilFinished) {
                if(startedtimer) {
                    earntime = selectTimebank();
                    earntime = earntime - 1;
                    stopTimeBank = earntime;
                    Log.e("earn time tick", "" + earntime);
                    saveTimebank();
                    startedtimer = true;
                }
            }


        };
            mCountDownTimer.start();
    }

    public void saveTimebank() {

        String updateQuery = "update " + timeBankDao.TABLENAME
                + " set " + TimeBankDao.Properties.TimeBank.columnName + "=?"
                + " where " + TimeBankDao.Properties.StudId.columnName + "=?";

        timeBankDao.getDatabase().execSQL(updateQuery, new Object[]{"" + earntime, StudentId});


    }

    public void UsageDetail(int zeroTimeBank)
    {
        stopcountdown=System.currentTimeMillis();
        long curtime = System.currentTimeMillis();
        stopTimeBank = selectTimebank();
        SimpleDateFormat curFormater = new SimpleDateFormat("MM/dd/yyyy");
        String date = ""+ curFormater.format(new Date());
         TimeSpendOutSideDao timespend = daoSessiontime.getTimeSpendOutSideDao();
        TimeSpendOutSide item = new TimeSpendOutSide();
        item.setTimeBankStatusBefore(""+startTimeBank);
        item.setTimeBankStatusAfter(""+stopTimeBank);
        item.setDate(date);
        item.setChildId(""+StudentId);
        item.setStartTime(""+startcountdown);
        item.setStopTime(""+stopcountdown);
        item.setZeroTimeBank(""+zeroTimeBank);
        timespend.insert(item);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

startcountdown=System.currentTimeMillis();
        con = getApplicationContext();
        //greendao code to access the database....
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);

        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        daoSessiontime =daoMaster.newSession();
        timeBankDao = daoSession.getTimeBankDao();
        StudentId = readFromPreference(this, PREF_CHILD_ID, "0");


        earntime = selectTimebank();
        startTimeBank = earntime;
        //earntime is less than or equal to 0 we restart the app from splash screen
        if (earntime <= 0) {
            callNewActivity_clear(con, SplashScreen.class);
        }

        //start the time using the object of the service created in constants so that this same object can be used in the splashscreen to stop the timer.

        if (!startedtimer) {
            startedtimer=true;
            objcaltime.MyTime2(getApplicationContext());
        }
        Log.e("earn time", "" + earntime);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

}