package com.ebravium.ecarrot.Services;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import com.ebravium.ecarrot.AskPassword;
import com.ebravium.ecarrot.SplashScreen;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.ManageDestinationAppDao;
import com.ebravium.ecarrot.model.TimeUsageDetails;
import com.ebravium.ecarrot.model.TimeUsageDetailsDao;
import com.ebravium.ecarrot.model.Usage_detail;
import com.ebravium.ecarrot.model.Usage_detailDao;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.SortedMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.callhome;
import static com.ebravium.ecarrot.Common.CommonFuctions.loadSavedPreferences;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_CHILD_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_RUNNING;
import static com.ebravium.ecarrot.Common.eCarrotConstants.RunService;
import static com.ebravium.ecarrot.Common.eCarrotConstants.anspass;
import static com.ebravium.ecarrot.Common.eCarrotConstants.objcaltime;

public class CheckUninstall extends Service {
    private  int stoff = 0;
    private  int ston = 0;
    private boolean trun = true;
    private String str123 = "hi";
    private Timer timer = new Timer();
    private Timer timer1 = new Timer();
    private Handler myHandler = new Handler();
    private int i = 0;
    private int m = 0;
    private Context context;

    private boolean executeflag=false;
    static String prevApp= "0";
    static String prevpkg= "0";
    static long startTime=0;
    static long stopTime=0;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;

    DaoMaster.DevOpenHelper helper;
    private Usage_detailDao usage_dao;
    private String childId;
    private ManageDestinationAppDao destidao;

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

     Handler m_handler;
     Runnable m_handlerTask ;

    public void Timertask() {


        m_handler = new Handler();

        m_handlerTask = new Runnable()
        {

            int i = 0;
            private PackageManager pm;
            private ActivityInfo activity;
            private SharedPreferences pref;
            private ApplicationInfo ai;
            private String AppName;
            private boolean SayRunning;
            private String actontop;
            @Override
            public void run() {
                m_handler.postDelayed(m_handlerTask, 1000);

                //Below code is from greendao used to save and reteive the data from the datbase
                helper = new DaoMaster.DevOpenHelper(context, "eCarrot.db", null);
                db = helper.getWritableDatabase();
                daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
                daoSession = daoMaster.newSession();
                usage_dao = daoSession.getUsage_detailDao();
//ends here

//The below code is written to fetch the currently running program
                pm = context.getPackageManager();
                ActivityManager am = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
                List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);

                List<ActivityManager.RunningAppProcessInfo> tasks = am.getRunningAppProcesses();
try {
    String mPackageName = tasks.get(0).processName;
}catch (Exception e)
{

}
                String str = "";
                String pknm = "";
                Boolean isScreenOn = true;


                PowerManager pm1 = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
                    isScreenOn = pm1.isInteractive();
                } else {
                    isScreenOn = pm1.isScreenOn();
                }
                if (!isScreenOn) {
                    Log.e("Screenoff", "Screenoff");
                    objcaltime.stoptimer();
                }

                if (taskInfo.size() > 0) {
                    str = taskInfo.get(0).topActivity.getClassName().toString();
                    actontop = str;
                    ComponentName comName = taskInfo.get(0).baseActivity;
                    pknm = comName.getPackageName().toString();
                    try {
                        ai = pm.getApplicationInfo(pknm, 0);
                        //App name is retrieved..
                        AppName = (String) pm.getApplicationLabel(ai);
                    } catch (NameNotFoundException e) {

                    }

                    int i;

                    i = str.lastIndexOf(".");
                    str = str.substring(0, i);
                    i = str.lastIndexOf(".");
                    //package name is rettrived for the current running app.
                    String str1 = str.substring(0, i);

                }


//Special code for Lollipop and aove version to get the current app which is runnin
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    UsageStatsManager mUsageStatsManager = (UsageStatsManager) getSystemService("usagestats");
                    long time = System.currentTimeMillis();
                    // We get usage stats for the last 10 seconds
                    List<UsageStats> stats = mUsageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 1000 * 10, time);
                    // Sort the stats by the last time used
                    //  Log.e("LIST SIZE",""+stats.size());
                    if (stats != null) {
                        SortedMap<Long, UsageStats> mySortedMap = new TreeMap<Long, UsageStats>();
                        for (UsageStats usageStats : stats) {
                            mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                        }
                        if (mySortedMap != null && !mySortedMap.isEmpty()) {

                            str = mySortedMap.get(mySortedMap.lastKey()).getPackageName();
                            pknm = str;

                        }
                    }

                    ApplicationInfo ai;
                    try {
                        ai = pm.getApplicationInfo(pknm, 0);
                    } catch (final NameNotFoundException e) {
                        ai = null;
                    }
                     AppName=""+(String)((ai != null) ? pm.getApplicationLabel(ai) : "???");
                }
                AppName=(Character.toUpperCase(AppName.charAt(0)) + AppName.substring(1).toLowerCase()).trim();
                // Ends here th code to retrive the current running app

                //This is the boolean which is checked if the app is supposed to be running or not
                //it is set to false when child does the cashout
                SayRunning = loadSavedPreferences(getApplicationContext(), PREF_ECARROT_RUNNING);
                childId = readFromPreference(getApplicationContext(),PREF_CHILD_ID,"0");
                destidao = daoSession.getManageDestinationAppDao();

                //This is where the blocking app code begins

                //check if the child currently logged in has some apps in the manage destination database

                final  String SQL_MG_DE_CT = "select * from " + ManageDestinationAppDao.TABLENAME + " where " + ManageDestinationAppDao.Properties.ChildId.columnName + " = '" + childId+"'";
                Cursor curct = daoSession.getDatabase().rawQuery(SQL_MG_DE_CT, null);



                if(curct.getCount()>0)
                {
                    //check if the child currently logged in is allowed to use this app. by checking the currentapp status in database whether it is 1
                   final  String SQL_APP_IN_DATABASE = "SELECT "+ManageDestinationAppDao.Properties.Status.columnName+" From "  + ManageDestinationAppDao.TABLENAME + " where " + ManageDestinationAppDao.Properties.ChildId.columnName + " = '" + childId + "' AND " + ManageDestinationAppDao.Properties.PackageName.columnName + " = '" + pknm + "' AND " + ManageDestinationAppDao.Properties.Status.columnName + " = '1'";
                    Cursor cur = daoSession.getDatabase().rawQuery(SQL_APP_IN_DATABASE, null);

                    if(cur.getCount()>0){
                        try {
                          callhome(getApplicationContext());

                        }catch (Exception e){

                        }
                        showToast(getApplicationContext(),"This app usage is blocked by the admin please contact admin for further details.");
                    }

                    }
//This is where the blocking app code ends


                // App usage tracking code starts here
                if (!readFromPreference(context, PREF_CHILD_ID, "0").equals("0"))
                {
                    if (!AppName.equals(prevApp)) {
                        if (startTime == 0) {
                            prevApp = AppName;
                            prevpkg = pknm;
                            startTime = System.currentTimeMillis();
                            //  Log.e("StartTime",""+startTime);

                        } else {
                            stopTime = System.currentTimeMillis();
                            SimpleDateFormat curFormater = new SimpleDateFormat("MM/dd/yyyy");
                            String prevdate = ""+ curFormater.format(new Date());
                            TimeUsageDetailsDao timeusage = daoSession.getTimeUsageDetailsDao();
                            TimeUsageDetails timeUsageDetails = new TimeUsageDetails();
                            timeUsageDetails.setAppName(prevApp);
                            timeUsageDetails.setPackageName(prevpkg);
                            timeUsageDetails.setChildId(readFromPreference(context, PREF_CHILD_ID, "0"));
                            timeUsageDetails.setDate(prevdate);

                            timeUsageDetails.setStartTime(""+startTime);
                            timeUsageDetails.setStopTime(""+stopTime);
                            timeusage.insert(timeUsageDetails);
                            //Log.e("StopTime",""+stopTime);
                            long usagetime = stopTime - startTime;
                            //Log.e("usage",""+usagetime);
                            startTime = 0;


                            Usage_detail item = new Usage_detail();
                            item.setAppName(prevApp);
                            item.setAppPackageName(prevpkg);
                            item.setChildId(readFromPreference(context, PREF_CHILD_ID, "0"));
                            item.setDate(prevdate);
                            List<Usage_detail> usage = usage_dao.queryBuilder().where(Usage_detailDao.Properties.AppName.eq(prevApp),Usage_detailDao.Properties.Date.eq(prevdate)).list();

                            if (usage.size() > 0) {

                                Usage_detail item1 = usage.get(0);
                                int t = Integer.parseInt(item1.getNoOfTime()) + 1;
                                item.setNoOfTime("" + t);
                                int tt = (int) (Long.parseLong(item1.getTotalTime()) + TimeUnit.MILLISECONDS.toSeconds(usagetime));
                                item.setTotalTime("" + tt);

                                //Greendao code to update the database, if the app was rpreviously used.
                                String updateQuery = "update " + Usage_detailDao.TABLENAME
                                        + " set " + Usage_detailDao.Properties.TotalTime.columnName + "=?"
                                        + " where " + Usage_detailDao.Properties.AppName.columnName + "=? and "+Usage_detailDao.Properties.Date.columnName+"=?";

                                usage_dao.getDatabase().execSQL(updateQuery, new Object[]{"" + tt, prevApp,prevdate});

                                String updateQuery1 = "update " + Usage_detailDao.TABLENAME
                                        + " set " + Usage_detailDao.Properties.NoOfTime.columnName + "=?"
                                        + " where " + Usage_detailDao.Properties.AppName.columnName + "=? and "+Usage_detailDao.Properties.Date.columnName+"=?";

                                usage_dao.getDatabase().execSQL(updateQuery1, new Object[]{"" + t, prevApp,prevdate});


                            } else {
                                //else the app usage is inserterd in the database
                                item.setNoOfTime("1");
                                int tmt = (int) TimeUnit.MILLISECONDS.toSeconds(usagetime);
                                item.setTotalTime("" + tmt);
                                usage_dao.insert(item);
                            }


                        }

                    }
            }
                //App usage tracking code ends here


                if(!SayRunning&&actontop.equals("com.android.settings.DeviceAdminAdd")&&!anspass)
                {
                    //  Log.e("saSA","AskPA");
                    callNewActivity_clear(getApplicationContext(), AskPassword.class);
                }

                //if Say running is true means no one has done the admin override or Chasout and th current app opened is not the
                // ecarrot then the splasscreen activity is called back again,

                if (SayRunning == true && !str.contains("com.google.android.voicesearch") && !str.contains("com.ebravium.ecarrot") && !str.equals("com.android.contacts") && !str.equals("com.android.phone") && !str.equals("com.android.contacts.activities") && !str.equals("com.android.htccontacts") && !str.equalsIgnoreCase("nl.changer.polypicker") && !str.equalsIgnoreCase("com.android.camera") && !str.equalsIgnoreCase("com.android.settings"))
 {

                    callNewActivity_clear(getApplicationContext(), SplashScreen.class);
       }
if (RunService)
{
    //m_handlerTask.run();


}else{m_handler.removeCallbacks(m_handlerTask);

}

            }


        };

        m_handlerTask.run();
    }



    @Override
    public void onCreate() {
        // formattedDate have current date/time

        //		Toast.makeText(this, formattedDate1, Toast.LENGTH_SHORT).show();


        super.onCreate();
    }

    @Override
    public void onDestroy() {


    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        //We start Notification as it is said that as long as the notification is there our app gets the priority and is kept live // even during the deadlock phase
        Notification notification = new Notification();

        notification.flags |= Notification.FLAG_NO_CLEAR;
        startForeground(1, notification);
        context = getApplicationContext();
        //RunServier is the boolean used to turn on or off the service… The timer task is a separate thread which runs in //the background based on the Runservice we determine whether it has to be started or not
        if (RunService)
            Timertask();

        return START_STICKY;
    }


}