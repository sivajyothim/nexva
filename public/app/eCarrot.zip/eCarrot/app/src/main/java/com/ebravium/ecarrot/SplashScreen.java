package com.ebravium.ecarrot;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.ebravium.ecarrot.Common.CommonFuctions;
import com.ebravium.ecarrot.ConnectServer.Fetchdata;
import com.ebravium.ecarrot.ConnectServer.JSONResponse;
import com.ebravium.ecarrot.Fragments.SignIn;
import com.ebravium.ecarrot.Services.CheckUninstall;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.savePreferences;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_CASHOUT;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_RUNNING;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_LOGIN;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_SHOW_PAY;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_VERIFIED;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_WEB_ID;
import static com.ebravium.ecarrot.Common.eCarrotConstants.RunService;
import static com.ebravium.ecarrot.Common.eCarrotConstants.URL_CHECK_PAYMENT_STATUS;
import static com.ebravium.ecarrot.Common.eCarrotConstants.URL_CHECK_VERIFICATION_STATUS;
import static com.ebravium.ecarrot.Common.eCarrotConstants.objcaltime;


public class SplashScreen extends AppCompatActivity implements JSONResponse {

    private static final int STATE_VERIFI = 0;
    private static final int STATE_PAYMENT = 1;
    private static int state = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        Log.e("Splashscreen","SplashScreen");
        /*This is the splash screen activity
        * below line saves in the shared preference that the app is running which is used in
        * check uninstall method this is sent to false when the user unlocks set to true when the
        * splash screen comes back*/
        if(!readFromPreference(SplashScreen.this,PREF_WEB_ID,"0").equals("0")) {
            savePreferences(this, PREF_ECARROT_RUNNING, true);
        }else {
            savePreferences(this, PREF_ECARROT_RUNNING, false);
        }
        /*This is the object defined in static constants file
        of service Which starts and stops the count down timer the below code is used to stop the timer*/
        objcaltime.stoptimer();
        saveToPreference(this,PREF_ECARROT_CASHOUT,"0");
        timer.start();


    }

    /* Heshan */
    View.OnClickListener dismissListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
        }
    };

    View.OnClickListener homeListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            CommonFuctions.dismissAlert();
            callNewActivity_clear(SplashScreen.this, HomeActivity.class);
            finish();
        }
    };

    View.OnClickListener verifyListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            callNewActivity_clear(SplashScreen.this, VerificationActivity.class);
        }
    };

    View.OnClickListener paymentListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            callNewActivity_clear(SplashScreen.this, PaymentActivity.class);
        }
    };

    View.OnClickListener paymentCancelListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            RunService = false;
            savePreferences(SplashScreen.this, PREF_ECARROT_RUNNING,false);
            Intent intent = new Intent(SplashScreen.this, CheckUninstall.class);
            stopService(intent);
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    };

    View.OnClickListener remindListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
            callNewActivity_clear(SplashScreen.this, PaymentActivity.class);
            finish();
        }
    };

    private void checkUserVerificationStatus(String userId) {
        Map<String, String> map = new HashMap<>();
        map.put("user_id", userId);
        CommonFuctions.showProgressDialog(this, "Checking user details...");
        Fetchdata ft = new Fetchdata(SplashScreen.this, URL_CHECK_VERIFICATION_STATUS, map);
        ft.getData();
        ft.jsonResponse = this;
    }

    private void checkUserPaymentStatus(String userId) {
        Map<String, String> map = new HashMap<>();
        map.put("user_id", userId);
        CommonFuctions.showProgressDialog(this, "Checking payment status...");
        Fetchdata ft = new Fetchdata(SplashScreen.this, URL_CHECK_PAYMENT_STATUS, map);
        ft.getData();
        ft.jsonResponse = this;
    }

    @Override
    public void getData(JSONObject response) throws JSONException {
        try {
            Log.e("REsponse",response.toString());
            switch (SplashScreen.state) {
                case SplashScreen.STATE_VERIFI:
                    if (response.getString("error123").equals("1")) {
                        if (response.has("verification_status")) {
                            String status = response.getString("verification_status");
                            String verifiedDate = response.getString("varification_date");

                            if (status.equalsIgnoreCase("1")) {
                                //verified
                                saveToPreference(SplashScreen.this, PREF_VERIFIED, "1");
                                long difference = CommonFuctions.getDifferentBetWeenDays(verifiedDate);
                                if (difference < 11) {
                                    saveToPreference(SplashScreen.this,PREF_SHOW_PAY,"1");
                                    callNewActivity_clear(SplashScreen.this, HomeActivity.class);
                                    finish();
                                } else if(difference >= 11 && difference <= 14) {
                                    saveToPreference(SplashScreen.this,PREF_SHOW_PAY,"1");
                                    if (difference == 11) {
                                        CommonFuctions.alertPayment(SplashScreen.this,
                                                getResources().getString(R.string.alert_remind_11),
                                                remindListener, homeListener, "Ok", "Later");
                                    } else if (difference == 14){
                                        CommonFuctions.alertPayment(SplashScreen.this,
                                                getResources().getString(R.string.alert_remind_14),
                                                remindListener, homeListener, "Ok", "Later");
                                    } else {
                                        //go to home
                                        callNewActivity_clear(SplashScreen.this, HomeActivity.class);
                                        finish();
                                    }
                                } else {
                                    //check payment status
                                    SplashScreen.state = SplashScreen.STATE_PAYMENT;
                                    checkUserPaymentStatus(readFromPreference(SplashScreen.this,
                                            PREF_WEB_ID,""));
                                }
                            } else {
                                CommonFuctions.alertUser(SplashScreen.this,
                                        getResources().getString(R.string.alert_verify_failed),
                                        verifyListener);
                            }
                        } else {
                            CommonFuctions.alertUser(SplashScreen.this,
                                    getResources().getString(R.string.alert_common_failed),
                                    dismissListener);
                        }
                    } else {
                        CommonFuctions.alertUser(SplashScreen.this,
                                getResources().getString(R.string.alert_common_failed),
                                dismissListener);
                    }
                    break;

                case SplashScreen.STATE_PAYMENT:
                    if (response.getString("error123").equals("1")) {
                        if (response.has("final_payment_date")) {
                            String final_payment_date = response.getString("final_payment_date");
                            long difference = CommonFuctions.getDifferentBetWeenDays(final_payment_date);
                            if (difference > 0) {
                                saveToPreference(SplashScreen.this,PREF_SHOW_PAY,"1");
                                CommonFuctions.alertPayment(SplashScreen.this,
                                        getResources().getString(R.string.alert_subscription),
                                        paymentListener, paymentCancelListener, "Ok", "Later");
                            } else {
                                saveToPreference(SplashScreen.this,PREF_SHOW_PAY,"0");
                                callNewActivity_clear(SplashScreen.this, HomeActivity.class);
                                finish();
                            }
                        } else {
                            CommonFuctions.alertUser(SplashScreen.this,
                                    getResources().getString(R.string.alert_common_failed),
                                    dismissListener);
                        }
                    } else {
                        CommonFuctions.alertUser(SplashScreen.this,
                                getResources().getString(R.string.alert_common_failed),
                                dismissListener);
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    /*--end--*/
    /*count down timer which is set for 3 sec and once this is over we call the login activity or
    the home activity*/
    CountDownTimer timer = new CountDownTimer(3000,1000) {
        @Override
        public void onTick(long millisUntilFinished) {

        }

        @Override
        public void onFinish()
        { //WE check if the shared preference PREF_WEB_ID returns zero implies that the admin has
            // not logged in so we start login sign up activity
            if(readFromPreference(SplashScreen.this,PREF_WEB_ID,"0").equals("0")) {
                callNewActivity_clear(SplashScreen.this,LoginSignupActivity.class);
            } else {
                if(readFromPreference(SplashScreen.this, PREF_VERIFIED,"0").equals("0")) {
                    callNewActivity_clear(SplashScreen.this, VerificationActivity.class);
                } else {
                    //Else we start the home activity
                    SplashScreen.state = SplashScreen.STATE_VERIFI;
                    checkUserVerificationStatus(readFromPreference(SplashScreen.this,
                            PREF_WEB_ID, ""));
                }
            }
        }
    };


}
