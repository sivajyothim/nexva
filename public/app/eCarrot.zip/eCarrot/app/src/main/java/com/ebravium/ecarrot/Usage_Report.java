package com.ebravium.ecarrot;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.ebravium.ecarrot.Adapters.UsageReport;
import com.ebravium.ecarrot.Reporting.Detail_Usage_Reporting;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.Usage_detail;
import com.ebravium.ecarrot.model.Usage_detailDao;

import com.ebravium.ecarrot.Adapters.UsageDetailReport;
import com.ebravium.ecarrot.Adapters.UsageReport;
import com.ebravium.ecarrot.Common.DetailReporting;
import com.ebravium.ecarrot.Reporting.Detail_Usage_Reporting;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.ReportingDao;
import com.ebravium.ecarrot.model.TimeBankDao;
import com.ebravium.ecarrot.model.Usage_detail;
import com.ebravium.ecarrot.model.Usage_detailDao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Usage_Report extends AppCompatActivity {

    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private ListView lstusage;
    private List<Usage_detail> arrlstusage = new ArrayList<>();
    private String StudentId;
    private String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usage__report);
        initview();
    }
    public void initview(){
        StudentId=getIntent().getStringExtra("stdid");
        date =getIntent().getStringExtra("date");
        lstusage= (ListView)findViewById(R.id.lstusage);
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        arrange_usage_report();
        lstusage.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Usage_detail item= arrlstusage.get(position);
                Intent intent = new Intent(Usage_Report.this,Detail_Usage_Reporting.class);
                intent.putExtra("chdid",StudentId);
                intent.putExtra("date",date);
                intent.putExtra("appname",item.getAppName());
                startActivity(intent);
            }
        });
    }

    public void arrange_usage_report()
    {
      //  Usage_detailDao cd = daoSession.getUsage_detailDao();

        String SQL_REPORTING_DATA="SELECT * " + " FROM " + Usage_detailDao.TABLENAME + " where " +
                Usage_detailDao.Properties.ChildId.columnName + " = '" + StudentId +
                "' AND "+Usage_detailDao.Properties.Date.columnName+" = '"+date+"'";


        Cursor cur = daoSession.getDatabase().rawQuery(SQL_REPORTING_DATA, null);
        while(cur.moveToNext())
        {
            Usage_detail usage = new Usage_detail();
           usage.setDate(cur.getString(cur.getColumnIndex(Usage_detailDao.Properties.Date.columnName)));
            usage.setAppName(cur.getString(cur.getColumnIndex(Usage_detailDao.Properties.AppName.columnName)));
            usage.setAppPackageName(cur.getString(cur.getColumnIndex(Usage_detailDao.Properties.AppPackageName.columnName)));
            usage.setTotalTime(cur.getString(cur.getColumnIndex(Usage_detailDao.Properties.TotalTime.columnName)));
            usage.setNoOfTime(cur.getString(cur.getColumnIndex(Usage_detailDao.Properties.NoOfTime.columnName)));

            arrlstusage.add(usage);
        }

       // arrlstusage=cd.queryBuilder().where(Usage_detailDao.Properties.ChildId.eq(StudentId)).list();
        UsageReport adapter = new UsageReport(this,arrlstusage);
        lstusage.setAdapter(adapter);
    }

}
