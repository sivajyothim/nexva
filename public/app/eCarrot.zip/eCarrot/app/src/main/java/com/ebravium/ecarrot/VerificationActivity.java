package com.ebravium.ecarrot;

import android.app.Dialog;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.ebravium.ecarrot.Common.CommonFuctions;
import com.ebravium.ecarrot.ConnectServer.Fetchdata;
import com.ebravium.ecarrot.ConnectServer.JSONResponse;
import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.Parent_Login;
import com.ebravium.ecarrot.model.Parent_LoginDao;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_MOBILE;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_TOKEN;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_VERIFIED;
import static com.ebravium.ecarrot.Common.eCarrotConstants.URL_CREATE_USER;
import static com.ebravium.ecarrot.Common.eCarrotConstants.URL_GET_SMS;

/* added by Heshan */
public class VerificationActivity extends AppCompatActivity implements JSONResponse {

    private EditText editText;
    private Button button;
    private Dialog dialog;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;

    private static int STATE_NOTIFY = 0;
    private static int STATE_VERIFY = 1;
    private static int STATE_VERIFY_SUBMIT = 2;
    private static int STATE = 0;
    private static String TOKEN = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        VerificationActivity.STATE = VerificationActivity.STATE_NOTIFY;

        initView();
        showAlert(getResources().getString(R.string.verification_message_notify));
    }

    View.OnClickListener dismissListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CommonFuctions.dismissAlert();
        }
    };

    /*
    init view
    * */
    private void initView() {
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(VerificationActivity.this,
                "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();

        editText = findViewById(R.id.verify_et_code);
        button = findViewById(R.id.verify_btn_verify);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (VerificationActivity.STATE == VerificationActivity.STATE_NOTIFY) {
                    if(!editText.getText().toString().equals("") &&
                            !editText.getText().equals("")) {
                        requestSMS(editText.getText().toString());
                    }
                } else {
                    if(!TextUtils.isEmpty(editText.getText()) &&
                            !editText.getText().toString().equals("")) {
                        matchCodes(editText.getText().toString());
                    }
                }
            }
        });
    }

    /*
    web and data requests
    * */
    private void requestSMS(String phone) {
        if (CommonFuctions.checkPhone(phone)) {
            Map<String, String> map = new HashMap<>();
            map.put("mobile_number", "+".concat(phone.trim().replace("+", "")));
            CommonFuctions.showProgressDialog(this, "Checking user details...");
            Fetchdata ft = new Fetchdata(this, URL_GET_SMS, map);
            ft.getData();
            ft.jsonResponse = this;
        } else {
            CommonFuctions.alertUser(this,
                    getResources().getString(R.string.alert_phone_failed), dismissListener);
        }
    }

    private void createUser() {
        Parent_LoginDao parent_loginDao = daoSession.getParent_LoginDao();
        List<Parent_Login> parent_logins = parent_loginDao.loadAll();

        if (parent_logins.size() > 0) {
            VerificationActivity.STATE = VerificationActivity.STATE_VERIFY_SUBMIT;
            Map<String, String> map = new HashMap<>();
            map.put("email", parent_logins.get(0).getEmail());
            map.put("ecarrot_user_id", parent_logins.get(0).getWeb_id());
            map.put("verification_status", "1");
            map.put("mobile_number", readFromPreference(this, PREF_MOBILE, ""));
            map.put("varification_code", readFromPreference(this, PREF_TOKEN, ""));
            CommonFuctions.showProgressDialog(this, "Checking user details...");
            Fetchdata ft = new Fetchdata(this, URL_CREATE_USER, map);
            ft.getData();
            ft.jsonResponse = this;
        }
    }

    private void matchCodes(String code) {
        if (code.equals(VerificationActivity.TOKEN)) {
            saveToPreference(this, PREF_TOKEN, code);
            saveToPreference(this, PREF_VERIFIED, "1");
            createUser();
        } else {
            CommonFuctions.alertUser(this, getResources().getString(R.string.alert_code_match_failed), dismissListener);
        }
    }

    /*
    helper methods
    * */
    private void showAlert(String message) {
        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.usage_instruction);
        dialog.setCancelable(false);
        TextView textView = dialog.findViewById(R.id.tvtext);
        textView.setText(message);
        Button button = dialog.findViewById(R.id.btok);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });
        dialog.show();
    }

    private void changeUILabels() {
        editText.setText("");
        editText.setHint("Verification code");
        button.setText("Verify");
    }

    @Override
    public void getData(JSONObject response) throws JSONException {

        try {
            Log.e("getData",response.toString());
            if (VerificationActivity.STATE == VerificationActivity.STATE_VERIFY_SUBMIT) {
                VerificationActivity.STATE = VerificationActivity.STATE_NOTIFY;
                callNewActivity_clear(this, VerifySuccessActivity.class);
                finish();
            } else {
                if (response.has("token")) {
                    VerificationActivity.TOKEN = response.getString("token");
                    saveToPreference(this, PREF_MOBILE, editText.getText().toString());
                    changeUILabels();
                    VerificationActivity.STATE = VerificationActivity.STATE_VERIFY;
                    showAlert(getResources().getString(R.string.verification_message_match));
                } else {
                    CommonFuctions.alertUser(this,
                            getResources().getString(R.string.alert_verify_failed), dismissListener);
                }
            }
        } catch (JSONException e){
            e.printStackTrace();
            CommonFuctions.alertUser(this,
                    getResources().getString(R.string.alert_common_failed), dismissListener);
        }
    }
}
