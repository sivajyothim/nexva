package com.ebravium.ecarrot;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;

/* added by Heshan */
public class VerifySuccessActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_success);

        init();
    }

    /*
    * init
    * */
    private void init() {
        Button btnHome = findViewById(R.id.verify_success_btn_home);
        Button btnActivate = findViewById(R.id.verify_success_btn_active);
        btnHome.setOnClickListener(this);
        btnActivate.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.verify_success_btn_home) {
            callNewActivity_clear(this, SplashScreen.class);
        } else if(view.getId() == R.id.verify_success_btn_active) {
            callNewActivity_clear(this, PaymentActivity.class);
        }
        finish();
    }
}
