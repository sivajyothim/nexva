package com.ebravium.ecarrot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.ebravium.ecarrot.Services.CalUseEarnTime;

import static com.ebravium.ecarrot.Common.CommonFuctions.callhome;
import static com.ebravium.ecarrot.Common.CommonFuctions.savePreferences;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_CASHOUT;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_RUNNING;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
public class Yes_No_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yes__no_);
    }
    public void Yes_Click(View v){
        savePreferences(this,PREF_ECARROT_RUNNING,false);
        saveToPreference(this,PREF_ECARROT_CASHOUT,"true");
        Intent intent = new Intent(this, CalUseEarnTime.class);
        startService(intent);
        finish();
        callhome(this);
    }
    public void No_Click(View v)
    {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        finish();
    }
}
