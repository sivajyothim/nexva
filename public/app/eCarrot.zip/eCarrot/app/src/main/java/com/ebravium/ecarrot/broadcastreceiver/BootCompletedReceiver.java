package com.ebravium.ecarrot.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.ebravium.ecarrot.SplashScreen;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;

/**
 * Created by osourcepro-laptop on 6/8/16.
 */
public class BootCompletedReceiver extends BroadcastReceiver{

    @Override
    public void onReceive(Context context, Intent intent) {
        callNewActivity_clear(context, SplashScreen.class);

    }
}
