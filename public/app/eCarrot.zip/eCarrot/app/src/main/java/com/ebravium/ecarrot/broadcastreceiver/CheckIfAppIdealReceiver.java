package com.ebravium.ecarrot.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.ebravium.ecarrot.Services.CalUseEarnTime;

import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_ECARROT_CASHOUT;

/** * Created by osourcepro-laptop on 6/8/16.

 */
public class CheckIfAppIdealReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

            if (!readFromPreference(context, PREF_ECARROT_CASHOUT, "0").equals("0")) {
                Intent intent1 = new Intent(context, CalUseEarnTime.class);
                context.startService(intent1);
            }
    }
}
