package com.ebravium.ecarrot.broadcastreceiver;

import android.app.admin.DeviceAdminReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;

import com.ebravium.ecarrot.AskPassword;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.CommonFuctions.saveToPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_DEVICE_ADMIN;
import static com.ebravium.ecarrot.Common.eCarrotConstants.anspass;

/**
 * Created by osourcepro-laptop on 30/7/16.
 */
public class DeviceAdmin extends DeviceAdminReceiver {

    @Override
    public void onEnabled(Context context, Intent intent) {
saveToPreference(context,PREF_DEVICE_ADMIN,"1");

    }
    @Override
    public void onReceive(Context context, Intent intent) {
        //uninst=true;
        //deviceadminclose=true;
        if(!anspass)

        if(intent.getAction().equalsIgnoreCase("android.app.action.DEVICE_ADMIN_DISABLE_REQUESTED") )
        {
            ContentResolver cr = context.getContentResolver();

            if(readFromPreference(context,PREF_DEVICE_ADMIN,"0").equals("0"))
            {
                super.onReceive(context, intent);
            }
            else {
                callNewActivity_clear(context, AskPassword.class);
                //Intent in=new Intent("android.app.action.DEVICE_ADMIN_ENABLED");
                //super.onReceive(context, in);
                //super.onEnabled(context, in);




                try {
                    Thread.sleep(3000);
                    super.onReceive(context, intent);
                } catch (InterruptedException e) {
                }

            }

        }
        else
        {
            super.onReceive(context, intent);
        }

        //onDisableRequested(context, intent);
        //onDisableRequested(context, intent);

    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "admin_receiver_status_disable_warning";
    }

    @Override
    public void onDisabled(Context context, Intent intent) {

        saveToPreference(context,PREF_DEVICE_ADMIN,"0");

    }
}