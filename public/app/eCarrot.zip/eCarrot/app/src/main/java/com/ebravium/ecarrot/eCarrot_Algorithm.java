package com.ebravium.ecarrot;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.ebravium.ecarrot.model.DaoMaster;
import com.ebravium.ecarrot.model.DaoSession;
import com.ebravium.ecarrot.model.LevelForStudent;
import com.ebravium.ecarrot.model.LevelForStudentDao;
import com.ebravium.ecarrot.model.Reporting;
import com.ebravium.ecarrot.model.ReportingDao;
import com.ebravium.ecarrot.model.TimeBank;
import com.ebravium.ecarrot.model.TimeBankDao;
import com.ebravium.ecarrot.model.TimeSpendOutSide;
import com.ebravium.ecarrot.model.TimeSpendOutSideDao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static com.ebravium.ecarrot.Common.CommonFuctions.callNewActivity_clear;
import static com.ebravium.ecarrot.Common.CommonFuctions.secondsToHrMinSec;
import static com.ebravium.ecarrot.Common.CommonFuctions.showToast;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_2_SEC;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_4_SEC;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_5_SEC;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_CHILD_ID;

import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_CHILD_NAME;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_LOCK;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PASSWORD;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PENALTY;
import static com.ebravium.ecarrot.Common.eCarrotConstants.StudentId;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_PENALTY;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr10;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1010;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr11;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr111;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1111;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr12;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1212;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr13;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1313;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr14;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1414;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr15;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1515;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr16;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1616;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr17;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1717;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr18;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1818;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr19;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1919;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr20;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2020;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr21;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2121;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr22;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr222;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2222;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr23;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2323;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr24;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2424;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr25;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2525;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr26;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2626;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr27;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2727;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr28;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2828;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr29;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr2929;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr3;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr30;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr3030;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr31;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr3131;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr32;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr3232;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr33;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr3333;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr34;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr3434;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr4;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr44;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr5;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr55;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr6;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr66;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr7;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr77;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr8;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr88;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr9;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr99;

import static com.ebravium.ecarrot.Common.eCarrotConstants.arrlockaddfirst;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arrlockaddsecond;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arrlockmulfirst;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arrlockmulsecond;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arrlocksubfirst;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arrlocksubsecond;
import static com.ebravium.ecarrot.Common.eCarrotConstants.earntime;
import static com.ebravium.ecarrot.Common.eCarrotConstants.startTimeBank;
import static com.ebravium.ecarrot.Common.eCarrotConstants.startcountdown;
import static com.ebravium.ecarrot.Common.eCarrotConstants.stopTimeBank;
import static com.ebravium.ecarrot.Common.eCarrotConstants.stopcountdown;

public class eCarrot_Algorithm extends AppCompatActivity
{

    int totaltimeearned=0;
    private SQLiteDatabase db;
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private EditText etanswer;
    int arrnum1[];
    int arrnum2[];

    int num1=-1;
    int num2=-1;
    int session;
    int level;
    int inarow;
    String StudentId;
    String StudentName;
    int correctincorrect=0;
    long StartTime;
    long StopTime;
    private LevelForStudentDao levelfromstudent_dao;
    ReportingDao reportingDao;
    private int ans;
    private TextView tvquestion;
boolean onlyonenum1=false;
    boolean onlyonenum2=false;

    int timecorr1=30;
    int timecorr2=20;
    int timecorr3=10;
    private int ansgiven;
    private long timetaken;
    private TimeBankDao timeBankDao;
    private long currenttimebank;
    private TextView tvinarow;
    private TextView tvtime;
    private String Question;
    private String date;
    private Dialog dgaskpass;
    private EditText etPass;
    private Button btSubmit;
    private TextView tvfpass;
    TextView tvlvl;
    public void Cashout_Click(View v){
        selectTimebank();
        if(currenttimebank>0)
        {
            callNewActivity_clear(this,Yes_No_Activity.class);
            finish();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_e_carrot__algorithm);
        initview();
        StudentId=readFromPreference(this,PREF_CHILD_ID,"0");
        StudentName=readFromPreference(this,PREF_CHILD_NAME,"0");
        selectsession();
        selectLevelInaRow();
        if(!randomlevel) {
            setArray();
            setQuestion();

        }else{
            Random r = new Random();
            level=r.nextInt(46)+1;
            setArray();
            setQuestion();
        }
        selectTimebank();
        checkStartTimeBank();
        tvtime.setText(secondsToHrMinSec(""+currenttimebank));
        dgaskpass=new Dialog(this);
        dgaskpass.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dgaskpass.setContentView(R.layout.dialog_check_pass);
        etPass=(EditText)dgaskpass.findViewById(R.id.etPass);
        btSubmit =(Button)dgaskpass.findViewById(R.id.btSubmit);
        tvfpass=(TextView)dgaskpass.findViewById(R.id.tvfpass);
        tvfpass.setVisibility(View.GONE);
        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dgaskpass.cancel();
                if(etPass.getText().toString().equals(readFromPreference(eCarrot_Algorithm.this,PREF_PASSWORD,"0")))
                {
                    level=level+1;

                    inarow=0;
                    tvinarow.setText("In a row:- "+inarow);
                    if(level<=46)
                    {
                        num1=-1;
                        num2=-1;
                        setArray();
                        updateLevelInaRow(level,0);
                        setQuestion();
                    }else{
                        Random r = new Random();
                        level=r.nextInt(46)+1;
                        updateLevelInaRow(47,0);
                        setArray();
                        setQuestion();
                    }

                }else{
                    showToast(eCarrot_Algorithm.this,getString(R.string.incorrect_password));
                }
                etPass.setText("");
                }
        });

    }
    public void Next_Level_Click(View v){
     dgaskpass.show();
    }
    public void initview()
    {
        SimpleDateFormat curFormater = new SimpleDateFormat("MM/dd/yyyy");
        date = ""+ curFormater.format(new Date());


        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getApplicationContext(), "eCarrot.db", null);
        db = helper.getWritableDatabase();
        daoMaster = new com.ebravium.ecarrot.model.DaoMaster(db);
        daoSession = daoMaster.newSession();
        timeBankDao =daoSession.getTimeBankDao();
        levelfromstudent_dao = daoSession.getLevelForStudentDao();
        reportingDao =daoSession.getReportingDao();

        etanswer=(EditText)findViewById(R.id.etanswer);
        tvquestion=(TextView)findViewById(R.id.tvquestion);
        tvinarow=(TextView)findViewById(R.id.tvinarow);
        tvtime=(TextView)findViewById(R.id.tvtime);
        tvlvl=(TextView)findViewById(R.id.tvlvl);
    }



    public void selectsession()
    {
        List lstsession=reportingDao.queryBuilder().where(ReportingDao.Properties.StudentId.eq(StudentId)).list();
        if(lstsession.size()>0)
        {
            Reporting reporting =(Reporting) lstsession.get(lstsession.size()-1);
            session=Integer.parseInt(reporting.getSessionId())+1;

        }else{
            session=1;
        }

    }
    boolean randomlevel=false;
    public void selectLevelInaRow()
    {
        List lstlevel=levelfromstudent_dao.queryBuilder().where(LevelForStudentDao.Properties.StudId.eq(StudentId)).list();

        if(lstlevel.size()>0){
            LevelForStudent levelForStudent=(LevelForStudent) lstlevel.get(0);
            level =Integer.parseInt(levelForStudent.getLevel());
            inarow=Integer.parseInt(levelForStudent.getInaRow());
            if(level==47)
                randomlevel=true;
            else
                randomlevel=false;


        }else{
            LevelForStudent levelForStudent = new LevelForStudent();
            levelForStudent.setInaRow("0");
            levelForStudent.setLevel("1");
            levelForStudent.setStudId(StudentId);
            daoSession.insert(levelForStudent);
            inarow=0;
            level=1;
        }
        Log.e("level",""+level);
    }


    public void updateLevelInaRow(int lvl, int row)
    {
        String updateQuery = "update " + LevelForStudentDao.TABLENAME
                + " set " + LevelForStudentDao.Properties.Level.columnName + "=?"
                + " where " + LevelForStudentDao.Properties.StudId.columnName + "=?";

        levelfromstudent_dao.getDatabase().execSQL(updateQuery, new Object[]{""+lvl, StudentId});


        String updateQuery1 = "update " + LevelForStudentDao.TABLENAME
                + " set " + LevelForStudentDao.Properties.InaRow.columnName + "=?"
                + " where " + LevelForStudentDao.Properties.StudId.columnName + "=?";

        levelfromstudent_dao.getDatabase().execSQL(updateQuery1, new Object[]{""+row, StudentId});


    }

    public void setArray()
    {
        if(level==1){

            tvlvl.setText("level 1-1");
            arrnum1=arr1;
            arrnum2=arr11;
            if(arr1.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr11.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }
        if(level==2){
            tvlvl.setText("level 1-2");
            arrnum1=arr2;
            arrnum2=arr22;
            if(arr2.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr22.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==3){
            tvlvl.setText("level 1-3");
            arrnum1=arr3;
            arrnum2=arr33;
            if(arr3.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr33.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }


        if(level==4){
            tvlvl.setText("level 1-4");
            arrnum1=arr4;
            arrnum2=arr44;
            if(arr4.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr44.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==5){
            tvlvl.setText("level 1-5");
            arrnum1=arr5;
            arrnum2=arr55;
            if(arr5.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr55.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==6){
            tvlvl.setText("level 2-1");
            arrnum1=arr6;
            arrnum2=arr66;
            if(arr6.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr66.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==7){
            tvlvl.setText("level 2-2");
            arrnum1=arr7;
            arrnum2=arr77;
            if(arr7.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr77.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }
        if(level==8){
            tvlvl.setText("level 2-3");
            arrnum1=arr8;
            arrnum2=arr88;
            if(arr8.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr88.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==9){
            tvlvl.setText("level 2-4");
            arrnum1=arr9;
            arrnum2=arr99;
            if(arr9.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr99.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==10){
            tvlvl.setText("level 2-5");
            arrnum1=arr10;
            arrnum2=arr1010;
            if(arr10.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1010.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==11){
            tvlvl.setText("level 2-6");
            arrnum1=arr111;
            arrnum2=arr1111;
            if(arr111.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1111.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==12){
            tvlvl.setText("level 2-7");
            arrnum1=arr12;
            arrnum2=arr1212;
            if(arr12.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1212.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==13){
            tvlvl.setText("level 3-1");
            arrnum1=arr13;
            arrnum2=arr1313;
            if(arr13.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1313.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==14){
            tvlvl.setText("level 3-2");
            arrnum1=arr14;
            arrnum2=arr1414;
            if(arr14.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1414.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==15){
            tvlvl.setText("level 3-3");
            arrnum1=arr15;
            arrnum2=arr1515;
            if(arr15.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1515.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==16){
            tvlvl.setText("level 3-4");
            arrnum1=arr16;
            arrnum2=arr1616;
            if(arr16.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1616.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==17){
            tvlvl.setText("level 3-5");
            arrnum1=arr17;
            arrnum2=arr1717;
            if(arr17.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1717.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==18){
            tvlvl.setText("level 3-6");
            arrnum1=arr18;
            arrnum2=arr1818;
            if(arr18.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1818.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==19){
            tvlvl.setText("level 3-7");
            arrnum1=arr19;
            arrnum2=arr1919;
            if(arr19.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1919.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==20){
            tvlvl.setText("level 3-8");
            arrnum1=arr20;
            arrnum2=arr2020;
            if(arr20.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr2020.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

        if(level==21){
            tvlvl.setText("level 3-9");
            arrnum1=arr21;
            arrnum2=arr2121;
            if(arr21.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr2121.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }
        if(level==22) {
            tvlvl.setText("level 4-1");
            arrnum1 = arr22;
            arrnum2 = arr2222;
        }



        if(level==23) {
            tvlvl.setText("level 4-2");
            arrnum1 = arr23;
            arrnum2 = arr2323;
        }

        if(level==24) {
            tvlvl.setText("level 4-3");
            arrnum1 = arr24;
            arrnum2 = arr2424;
        }
        if(level==25) {
            tvlvl.setText("level 4-4");
            arrnum1 = arr25;
            arrnum2 = arr2525;
        }
        if(level==26) {
            tvlvl.setText("level 4-5");
            arrnum1 = arr26;
            arrnum2 = arr2626;
        }
        if(level==27) {
            tvlvl.setText("level 4-6");
            arrnum1 = arr27;
            arrnum2 = arr2727;
        }

        if(level==28) {
            tvlvl.setText("level 4-7");
            arrnum1 = arr28;
            arrnum2 = arr2828;
        }
        if(level==29) {
            tvlvl.setText("level 4-8");
            arrnum1 = arr29;
            arrnum2 = arr2929;
        }

        if(level==30) {
            tvlvl.setText("level 4-9");
            arrnum1 = arr30;
            arrnum2 = arr3030;
        }
        if(level==31) {
            tvlvl.setText("level 4-10");
            arrnum1 = arr31;
            arrnum2 = arr3131;
        }
        if(level==32) {
            tvlvl.setText("level 4-11");
            arrnum1 = arr32;
            arrnum2 = arr3232;
        }

        if(level==33) {
            tvlvl.setText("level 4-12");
            arrnum1 = arr33;
            arrnum2 = arr3333;

        }
        if(level==34) {
            tvlvl.setText("level 4-13");
            arrnum1 = arr34;
            arrnum2 = arr3434;
        }

    }



    public void selectnumbers()
    {
        if(level<13) {
            if (onlyonenum1) {
                num1 = arrnum1[0];
            }
            if (onlyonenum2) {
                num2 = arrnum2[0];
            }
            Log.e("OnlyNum1",""+onlyonenum1+"  " + onlyonenum2+"  "+level+" arrnum1 "+ arrnum1.length+" arrnum2  "+ arrnum2.length);
            if (arrnum1.length >= 1 && !onlyonenum1) {
                if (arrnum1.length == 1) {
                    setArray();
                }
                if (num1 >= 0&&!randomlevel) {
                    int tmp[] = new int[arrnum1.length - 1];
                    int j = 0;
                    for (int i = 0; i < arrnum1.length; i++) {
                        if (num1 != arrnum1[i]) {
                            tmp[j] = arrnum1[i];
                            j++;
                        }
                    }
                    arrnum1 = tmp;
                }
                Random r = new Random();
                int index = r.nextInt(arrnum1.length);
                num1 = arrnum1[index];
            }

            if (arrnum2.length >= 1 && !onlyonenum2) {
                if (arrnum2.length == 1) {
                    setArray();
                }
                if (num2 >= 0&&!randomlevel) {
                    int tmp[] = new int[arrnum2.length - 1];
                    int j = 0;
                    for (int i = 0; i < arrnum2.length; i++) {
                        if (num2 != arrnum2[i]) {

                            tmp[j] = arrnum2[i];
                            j++;
                        }
                    }
                    arrnum2 = tmp;
                }
                Random r = new Random();
                int index = r.nextInt(arrnum2.length);
                num2 = arrnum2[index];
            }
        }

        if(level == 13 || level == 14 || level == 15 || level == 16 || level == 17 || level == 18 ||level==19||level==20||level==21){
            if (onlyonenum1) {
                num1 = arrnum1[0];
            }else{

                Random r = new Random();
                int index = r.nextInt(arrnum1.length);
                num1 = arrnum1[index];
            }
            if (onlyonenum2) {
                num2 = arrnum2[0];
            }else{
                Random r = new Random();
                int index = r.nextInt(arrnum2.length);
                num2 = arrnum2[index];
            }
            if(num1<num2){
                int c = num1;
                num1=num2;
                num2=c;
            }
        }

        if(level>21&&level<35   ){
            Random r = new Random();
            int index = r.nextInt(arrnum1.length);
            Log.e("Length",""+arrnum1.length);
            num1 = arrnum1[index];


             index = r.nextInt(arrnum2.length);
            num2 = arrnum2[index];
        }
        if(level==35)
        {
            tvlvl.setText("level 5-1");
            Random r = new Random();
            num1 = r.nextInt(12)+1;
            num2 = num1 *1;
            num1=1;
        }

        if(level==36)
        {

            tvlvl.setText("level 5-2");
            Random r = new Random();
            num1 = r.nextInt(12)+1;
            num2 = num1 *2;
            num1=2;
        }
        if(level==37)
        {
            tvlvl.setText("level 5-3");
            Random r = new Random();
            num1 = r.nextInt(12)+1;
            num2 = num1 *3;
            num1=3;
        }
        if(level==38)
        {
            tvlvl.setText("level 5-4");
            Random r = new Random();
            num1 = r.nextInt(12)+1;
            num2 = num1 *4;
            num1=4;
        }

        if(level==39)
    {
        tvlvl.setText("level 5-5");
        Random r = new Random();
        num1 = r.nextInt(12)+1;
        num2 = num1 *5;
        num1=5;
    } if(level==40)
    {
        tvlvl.setText("level 5-6");
        Random r = new Random();
        num1 = r.nextInt(12)+1;
        num2 = num1 *6;
        num1=6;
    } if(level==41)
    {
        tvlvl.setText("level 5-7");
        Random r = new Random();
        num1 = r.nextInt(12)+1;
        num2 = num1 *7;
        num1=7;
    } if(level==42)
    {
        tvlvl.setText("level 5-8");
        Random r = new Random();
        num1 = r.nextInt(12)+1;
        num2 = num1 *8;
        num1=8;
    }

        if(level==43)
        {
            tvlvl.setText("level 5-9");
            Random r = new Random();
            num1 = r.nextInt(12)+1;
            num2 = num1 *9;
            num1=9;
        }
        if(level==44)
        {
            tvlvl.setText("level 5-10");
            Random r = new Random();
            num1 = r.nextInt(12)+1;
            num2 = num1 *10;
            num1=10;
        }
        if(level==45)
        {
            tvlvl.setText("level 5-11");
            Random r = new Random();
            num1 = r.nextInt(12)+1;
            num2 = num1 *11;
            num1=11;
        }
        if(level==46)
        {
            tvlvl.setText("level 5-12");
            Random r = new Random();
            num1 = r.nextInt(12)+1;
            num2 = num1 *12;
            num1=12;
        }





    }

    public void setQuestion()
    {
        StartTime = System.currentTimeMillis();
        if(readFromPreference(this,PREF_LOCK,"0").equals("0")) {
            if (randomlevel) {
                Random r = new Random();
                level = r.nextInt(46) + 1;
                Log.e("level", "" + level);
                setArray();
            }
            if (level < 35) {

                selectnumbers();
                if (level == 1 || level == 2 || level == 3 || level == 4 || level == 5 || level == 6 || level == 7 || level == 8 || level == 9 || level == 10 || level == 11 || level == 12) {
                    ans = num1 + num2;
                    tvquestion.setText("" + num1 + "\n + " + num2);
                    Question = "" + num1 + " + " + num2;
                }

                if ( level == 13 || level == 14 || level == 15 || level == 16 || level == 17 || level == 18 || level == 19 || level == 20 || level == 21) {

                    ans = num1 - num2;
                    tvquestion.setText("" + num1 + "\n - " + num2);
                    Question = "" + num1 + " - " + num2;
                }

                if (level > 21) {
                    ans = num1 * num2;
                    tvquestion.setText("" + num1 + "\n X " + num2);
                    Question = "" + num1 + " X " + num2;
                }
            } else if (level <= 46) {

                selectnumbers();
                ans = num2 / num1;
                tvquestion.setText("" + num2 + "\n \u00F7 " + num1);
                Question = "" + num2 + " \u00F7 " + num1;
            } else {
                showToast(this, getString(R.string.levels_completed));
            }
        }else{
            if (randomlevel) {

                Random r = new Random();
                level = r.nextInt(46) + 1;
                Log.e("level", "" + level);
                setArray();
            }

            if(level>44)
            {

                showToast(this, getString(R.string.levels_completed));
                finish();

            }else{
                if(readFromPreference(this,PREF_LOCK,"0").equals("+"))
                {
                    Log.e("ADD LOCK","ADD LOCK");
                    onlyonenum1 = false;
                    onlyonenum2 = false;
                    arrnum1 = arrlockaddfirst;
                    arrnum2 = arrlockaddsecond;
                    selectAddLevel();
                    ans = num1 + num2;
                    tvquestion.setText("" + num1 + "\n + " + num2);
                    Question = "" + num1 + " + " + num2;
                }
                if(readFromPreference(this,PREF_LOCK,"0").equals("-"))
                {
                    Log.e("SUB LOCK","SUB LOCK");
                    onlyonenum1 = false;
                    onlyonenum2 = false;
                    arrnum1 = arrlocksubfirst;
                    arrnum2 = arrlocksubsecond;
                    selectSubLevel();
                    ans = num1 - num2;
                    tvquestion.setText("" + num1 + "\n - " + num2);
                    Question = "" + num1 + " - " + num2;
                }
                if(readFromPreference(this,PREF_LOCK,"0").equals("*"))
                {
                    Log.e("MUL LOCK","MUL LOCK");
                    onlyonenum1 = false;
                    onlyonenum2 = false;
                    arrnum1 = arrlockmulfirst;
                    arrnum2 = arrlockmulsecond;
                    Random r = new Random();
                    int index = r.nextInt(arrnum1.length);
                    Log.e("Length",""+arrnum1.length);
                    num1 = arrnum1[index];


                    index = r.nextInt(arrnum2.length);
                    num2 = arrnum2[index];

                    ans = num1 * num2;
                    tvquestion.setText("" + num1 + "\n X " + num2);
                    Question = "" + num1 + " X " + num2;
                }
                if(readFromPreference(this,PREF_LOCK,"0").equals("/"))
                {
                    Log.e("DIV LOCK","DIV LOCK");
                    onlyonenum1 = false;
                    onlyonenum2 = false;
                    Random r = new Random();
                    num1 = r.nextInt(12)+1;
                    int temp = r.nextInt(12)+1;
                    num2 = num1 *temp;
                    num1=temp;
                    ans = num2 / num1;
                    tvquestion.setText("" + num2 + "\n \u00F7 " + num1);
                    Question = "" + num2 + " \u00F7 " + num1;
                }

            }
        }

        Log.e("Numbers",num1+""+num2);
    }
    public void selectSubLevel()
    {
        Log.e("onlyonenum1",""+onlyonenum1);
        Log.e("onlyonenum2",""+onlyonenum2);

        if (onlyonenum1) {
            num1 = arrnum1[0];
        }else{

            Random r = new Random();
            int index = r.nextInt(arrnum1.length);
            num1 = arrnum1[index];
        }
        if (onlyonenum2) {
            num2 = arrnum2[0];
        }else{
            Random r = new Random();
            int index = r.nextInt(arrnum2.length);
            num2 = arrnum2[index];
        }
        if(num1<num2){
            int c = num1;
            num1=num2;
            num2=c;
        }
    }
    public void selectAddLevel()
    {
        if (onlyonenum1) {
            num1 = arrnum1[0];
        }else{

            Random r = new Random();
            int index = r.nextInt(arrnum1.length);
            num1 = arrnum1[index];
        }
        if (onlyonenum2) {
            num2 = arrnum2[0];
        }else{
            Random r = new Random();
            int index = r.nextInt(arrnum2.length);
            num2 = arrnum2[index];
        }
    }

    public void key1_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"1");
    }
    public void key2_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"2");
    }
    public void key3_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"3");
    }
    public void key4_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"4");
    }
    public void key5_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"5");
    }
    public void key6_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"6");
    }
    public void key7_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"7");
    }
    public void key8_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"8");
    }
    public void key9_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"9");
    }
    public void key0_click(View v)
    {
        String ans= etanswer.getText().toString();
        etanswer.setText(ans+"0");
    }
    public void keyback_click(View v){
        String ans =etanswer.getText().toString();
        if(!TextUtils.isEmpty(ans))
        {
            int l= ans.length();
            if(l>1)
            {
                l=l-1;
                etanswer.setText(ans.substring(0,l));
            }else{
                etanswer.setText("");
            }
        }
    }
int contincor =0;
public void keyenter_click(View v)
{
 if(!TextUtils.isEmpty(etanswer.getText().toString())) {
     try {
         ansgiven = Integer.parseInt(etanswer.getText().toString());
     } catch (NumberFormatException e) {

     }
     etanswer.setText("");
     StopTime = System.currentTimeMillis();
     timetaken = StopTime - StartTime;
     if (ans == ansgiven) {

         contincor=0;
         saveTimebank(true);
         inarow += 1;
         tvinarow.setText("In a row:- " + inarow);
         correctincorrect = 1;


     } else {
         saveTimebank(false);
         inarow = 0;
         tvinarow.setText("In a row:- " + inarow);
         correctincorrect = 0;
         contincor++;
         if(contincor>=2)
         {
          final Dialog   dgans= new Dialog(this);
             dgans.requestWindowFeature(Window.FEATURE_NO_TITLE);
             dgans.setContentView(R.layout.dgans);
             dgans.setCancelable(false);
             TextView tvtext = (TextView)dgans.findViewById(R.id.tvtext);
             tvtext.setText(Question+" = "+ans);
             Button btok = (Button)dgans.findViewById(R.id.btok);

             btok.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View view) {

                     dgans.cancel();
                 }
             });
            dgans.show();
         }
     }

     saveReportingdata();
     if(inarow==10)
     {
         AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, R.style.AlertDialogTheme);
         alertDialogBuilder.setMessage("Congratulations you have cleared the level "+level);
         alertDialogBuilder.setPositiveButton("ok",
                 new DialogInterface.OnClickListener() {
                     @Override
                     public void onClick(DialogInterface arg0, int arg1) {

                     }
                 });


       AlertDialog alertDialog= alertDialogBuilder.create();


         alertDialog.show();
     }
     if (inarow >= 10) {
         num1 = -1;
         num2 = -1;
         inarow = 0;

         level = level + 1;
         setArray();
         if (!randomlevel)
             updateLevelInaRow(level, 0);
         else
             updateLevelInaRow(47, 0);
     } else {
         if (!randomlevel)
             updateLevelInaRow(level, inarow);
         else
             updateLevelInaRow(47, inarow);
     }
     if(ans==ansgiven)
     {
         setQuestion();
     }

 }else{
     showToast(this,getString(R.string.please_enter_answer));
 }
}
public int toInteger(String text)
{
    try{
        return Integer.parseInt(text);
    }catch (Exception e)
    {
        return 0;
    }
}
    public void saveTimebank(boolean correctans)
    {       if(correctans) {
        if (timetaken <= 2000) {
            currenttimebank += toInteger(readFromPreference(this,PREF_2_SEC,"30"));
            totaltimeearned+=toInteger(readFromPreference(this,PREF_2_SEC,"30"));
        }
        if (timetaken > 2000 && timetaken <= 4000) {
            currenttimebank += toInteger(readFromPreference(this,PREF_4_SEC,"20"));
            totaltimeearned+=toInteger(readFromPreference(this,PREF_4_SEC,"20"));
        }
        if (timetaken > 4000) {
            currenttimebank += toInteger(readFromPreference(this,PREF_5_SEC,"10"));
            totaltimeearned+=toInteger(readFromPreference(this,PREF_5_SEC,"10"));
        }
    }else{
        currenttimebank -= toInteger(readFromPreference(this,PREF_PENALTY,"10"));
        totaltimeearned-=toInteger(readFromPreference(this,PREF_PENALTY,"10"));

    }
        String updateQuery = "update " + timeBankDao.TABLENAME
                + " set " + TimeBankDao.Properties.TimeBank.columnName + "=?"
                + " where " + TimeBankDao.Properties.StudId.columnName + "=?";

        timeBankDao.getDatabase().execSQL(updateQuery, new Object[]{""+currenttimebank, StudentId});
        tvtime.setText(secondsToHrMinSec(""+currenttimebank));

    }
    public void selectTimebank()
    {
        List lsttimebank=timeBankDao.queryBuilder().where(TimeBankDao.Properties.StudId.eq(StudentId)).list();
        if(lsttimebank.size()>0)
        {
            TimeBank timeBank = (TimeBank)lsttimebank.get(0);
            currenttimebank= Long.parseLong(timeBank.getTimeBank());
        }else{
            TimeBank timeBank = new TimeBank();
            timeBank.setStudId(""+StudentId);
            timeBank.setTimeBank(""+0);
            daoSession.insert(timeBank);
            currenttimebank=0;
        }

    }

    public void checkStartTimeBank()
    {
        Log.e("HEre",""+"Asdasd");;
        String SQL_REPORTING_DATA1 = "SELECT * " + " FROM " + TimeSpendOutSideDao.TABLENAME + " where " +
                TimeSpendOutSideDao.Properties.ChildId.columnName + " = '" + StudentId + "' AND " +
                TimeSpendOutSideDao.Properties.Date.columnName + " = '" + date + "'";
        Cursor cur1 = daoSession.getDatabase().rawQuery(SQL_REPORTING_DATA1, null);
if(cur1.getCount()==0)
{
    TimeSpendOutSideDao timespend = daoSession.getTimeSpendOutSideDao();
    TimeSpendOutSide item = new TimeSpendOutSide();
    item.setTimeBankStatusBefore(""+currenttimebank);
    item.setTimeBankStatusAfter("0");
    item.setDate(date);
    item.setChildId(""+StudentId);
    item.setStartTime("0");
    item.setStopTime("0");
    item.setZeroTimeBank("0");
    timespend.insert(item);
}
    }

    public void saveReportingdata()
    {
        Log.e("timetaken",""+timetaken);
        Reporting reporting = new Reporting();
        reporting.setSessionId(""+session);
        reporting.setAnswer(""+ansgiven);
        reporting.setExpectedAnswer(""+ans);
        reporting.setQuestion(""+Question);
        reporting.setStartTime(""+StartTime);
        reporting.setStopTime(""+StopTime);
        reporting.setTimeTaken(""+timetaken);
        reporting.setStudentId(""+StudentId);
        reporting.setStudentName(""+StudentName);
        reporting.setStatus(""+correctincorrect);
        reporting.setTimeEarned(""+totaltimeearned);
        reporting.setDate(date);
        daoSession.insert(reporting);

    }

}
