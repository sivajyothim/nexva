package com.ebravium.ecarrot;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import static com.ebravium.ecarrot.Common.CommonFuctions.readFromPreference;
import static com.ebravium.ecarrot.Common.eCarrotConstants.PREF_LOCK;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr19;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr1919;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr9;
import static com.ebravium.ecarrot.Common.eCarrotConstants.arr99;

public class eCarrot_Algorithm_Locks extends AppCompatActivity {

    int arrnum1[];
    int arrnum2[];
    boolean onlyonenum1=false;
    boolean onlyonenum2=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_e_carrot__algorithm);
        if(readFromPreference(this,PREF_LOCK,"0").equals("+"))
        {
            arrnum1=arr9;
            arrnum2=arr99;
            if(arr9.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr99.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }
        if(readFromPreference(this,PREF_LOCK,"0").equals("-"))
        {
            arrnum1=arr19;
            arrnum2=arr1919;
            if(arr19.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1919.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }
        if(readFromPreference(this,PREF_LOCK,"0").equals("*"))
        {
            arrnum1=arr19;
            arrnum2=arr1919;
            if(arr19.length==1){
                onlyonenum1=true;
            }else{
                onlyonenum1=false;
            }
            if(arr1919.length==1){
                onlyonenum2=true;
            }else{
                onlyonenum2=false;
            }
        }

    }
}
