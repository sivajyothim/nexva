package com.daogenerator;


import de.greenrobot.daogenerator.DaoGenerator;
import de.greenrobot.daogenerator.Entity;
import de.greenrobot.daogenerator.Schema;

public class CarrotDaoGenerator {

    private static void addTables(final Schema schema) {
        Entity parent_login = schema.addEntity("Parent_Login");
        parent_login.addStringProperty("name");
        parent_login.addStringProperty("email");
        parent_login.addStringProperty("pass");
        parent_login.addBooleanProperty("verified");
        parent_login.addStringProperty("web_id");

        Entity Child_Detail = schema.addEntity("Child_Details");
        Child_Detail.addStringProperty("child_name");
        Child_Detail.addStringProperty("child_id");
        Child_Detail.addStringProperty("age");
        Child_Detail.addStringProperty("image_url");
        Child_Detail.addStringProperty("time_bank");

        Entity Reporting = schema.addEntity("Reporting");
        Reporting.addStringProperty("SessionId");
        Reporting.addStringProperty("StudentId");
        Reporting.addStringProperty("StudentName");
        Reporting.addStringProperty("Question");
        Reporting.addStringProperty("Answer");
        Reporting.addStringProperty("ExpectedAnswer");
        Reporting.addStringProperty("StartTime");
        Reporting.addStringProperty("StopTime");
        Reporting.addStringProperty("TimeTaken");
        Reporting.addStringProperty("TimeEarned");
        Reporting.addStringProperty("Status");
        Reporting.addStringProperty("Date");

        Entity LevelforStudent = schema.addEntity("LevelForStudent");
        LevelforStudent.addStringProperty("StudId");
        LevelforStudent.addStringProperty("Level");
        LevelforStudent.addStringProperty("InaRow");

        Entity TimeBank = schema.addEntity("TimeBank");
        TimeBank.addStringProperty("StudId");
        TimeBank.addStringProperty("TimeBank");

        Entity Usage_detail = schema.addEntity("Usage_detail");
        Usage_detail.addStringProperty("ChildId");
        Usage_detail.addStringProperty("AppName");
        Usage_detail.addStringProperty("AppIcon");
        Usage_detail.addStringProperty("AppPackageName");
        Usage_detail.addStringProperty("NoOfTime");
        Usage_detail.addStringProperty("TotalTime");
        Usage_detail.addStringProperty("Status");
        Usage_detail.addStringProperty("Date");

        Entity ManageDestinationApp = schema.addEntity("ManageDestinationApp");
        ManageDestinationApp.addStringProperty("ChildId");
        ManageDestinationApp.addStringProperty("AppName");
        ManageDestinationApp.addStringProperty("PackageName");
        ManageDestinationApp.addStringProperty("Status");

        Entity TimeUsageDetails = schema.addEntity("TimeUsageDetails");
        TimeUsageDetails.addStringProperty("ChildId");
        TimeUsageDetails.addStringProperty("AppName");
        TimeUsageDetails.addStringProperty("PackageName");
        TimeUsageDetails.addStringProperty("StartTime");
        TimeUsageDetails.addStringProperty("StopTime");
        TimeUsageDetails.addStringProperty("Date");

        Entity TimeSpendOutSide = schema.addEntity("TimeSpendOutSide");
        TimeSpendOutSide.addStringProperty("ChildId");
        TimeSpendOutSide.addStringProperty("StartTime");
        TimeSpendOutSide.addStringProperty("StopTime");
        TimeSpendOutSide.addStringProperty("TimeBankStatusBefore");
        TimeSpendOutSide.addStringProperty("TimeBankStatusAfter");
        TimeSpendOutSide.addStringProperty("ZeroTimeBank");
        TimeSpendOutSide.addStringProperty("Date");
    }

    public static void main(String args[]) throws Exception {

        Schema schema = new Schema(1, "com.ebravium.ecarrot.model");
        schema.enableKeepSectionsByDefault();

        addTables(schema);

        try {
            new DaoGenerator().generateAll(schema, "/home/osourcepro-laptop/Desktop/chathurachanges/eCarrot/app/src/main/java");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
