$(document).ready(function(){
$("#search").daterangepicker();
});