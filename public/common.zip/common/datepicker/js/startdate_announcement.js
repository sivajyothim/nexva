$(document).ready(function(){
$("#validity").daterangepicker();

});