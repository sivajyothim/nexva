$(document).ready(function() {
    $('#user_register').ketchup();
});
