$.fn.ketchup.messages = {
  'required':     'Ce champ doit être rempli.',
  'minlength':    'Ce champ doit avoir une longueur minimale de $arg1.',
  'maxlength':    'Ce champ doit avoir une longueur maximale de $arg1.',
  'rangelength':  'Ce champ doit avoir une longueur entre $arg1 et $arg2.',
  'min':          'Must be at least $arg1.',
  'max':          'Doit être au moins $arg1.',
  'range':        'Doit être entre $arg1 et $arg2.',
  'number':       'Doit être un nombre.',
  'digits':       'Doit être des chiffres.',
  'email':        'Doit être un e-mail valide.',
  'url':          'Doit être une URL valide.',
  'username':     "Doit être un nom d'utilisateur valide.",
  'match':        'Doit correspondre au champ ci-dessus.',
  'date':         'Doit être une date valide.',
  'minselect':    'Cochez au moins $arg1.',
  'maxselect':    'Cochez pas plus de $arg1 cases.',
  'rangeselect':  'Cochez les cases entre $arg1 et $arg2.',
  'buildname':    'Le nom ne doit contenir que des nombres, des caractères, des espaces, "-" et "_".',     //this is a custom message, used for validate buildname in the CP panel
  'briefdescription':	'Ce champ doit avoir une longueur entre $arg1 et $arg2 caractères.'
};